# Club Arduino Lab

Arduino Mega 2560向けの部活動用シミュレータです。AppDeploy版の現在のUI・機能構成を、Netlifyへ移行できる独立したVite/Reactプロジェクトとしてまとめています。

## ローカル起動

```bash
npm install
npm run dev
```

## 本番ビルド

```bash
npm run build
```

Netlifyでは `netlify.toml` により `npm run build` を実行し、`dist` を公開します。

## 外部通信

BUILD & RUNではブラウザから `https://hexi.wokwi.com/build` にアクセスしてArduino Mega用HEXを生成します。

## 音源

- `public/resources/F1V10mintomaxnew.wav` : DCM連動音
- `public/resources/STPM.wav` : ステッピングモーターステップ音

## 移行メモ

AppDeploy版はバックアップとして残し、このプロジェクト側ではPROGRAM / I/Oの配置、ピン割り当て、AVR実行、保存、音声ロジックを維持しています。
