import ProgramLab from './ProgramLab';

function App() {
  return <ProgramLab />;
}

export default App;
