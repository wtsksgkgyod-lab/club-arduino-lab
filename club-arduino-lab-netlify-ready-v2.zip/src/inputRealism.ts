import type { ArduinoTarget } from './sim';

export type RealismSignal =
  | 'TC'
  | 'TG'
  | 'PH'
  | 'PR'
  | 'VR'
  | 'JOYX'
  | 'JOYY'
  | 'ENCA'
  | 'ENCB'
  | 'DSEN';

export type RealismDeviceState = {
  tcPressed: boolean;
  tgHigh: boolean;
  phTransparent: boolean;
  prRaw: number;
  vrRaw: number;
  joyX: number;
  joyY: number;
  dsenMm: number;
};

export type RealismInputMapping = Record<RealismSignal, ArduinoTarget>;
export type ChatterSignal = 'TC' | 'TG' | 'PH';

export type ChatterTransition = {
  startedAt: number;
  durationMs: number;
  intervalMs: number;
  fromHigh: boolean;
  toHigh: boolean;
};

export type ChatterMap = Partial<Record<ChatterSignal, ChatterTransition>>;

export const DSEN_MIN_VALID_MM = 30;
export const DSEN_MAX_MM = 200;

const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const clampRaw = (value: number) => clamp(Math.round(value), 0, 1023);
const rawVoltage = (raw: number) => (clampRaw(raw) / 1023) * 5;
const fract = (value: number) => value - Math.floor(value);

const unit = (seed: number, channel: number) =>
  fract(Math.sin(seed * 0.000013 + channel * 17.317) * 43758.5453123);

const wave = (seed: number, channel: number, now: number) => {
  const a = Math.sin(now * (0.012 + channel * 0.0007) + seed * 0.00011 + channel * 1.71);
  const b = Math.sin(now * (0.037 + channel * 0.0009) + seed * 0.00007 + channel * 2.39);
  return a * 0.68 + b * 0.32;
};

export const dsenMmToRaw = (mm: number) => clampRaw((730 - mm) / 1.3);
export const dsenRawToMm = (raw: number) => Math.round(730 - clampRaw(raw) * 1.3);

export function readInputRealismSeed() {
  const saved = Number(localStorage.getItem('club-input-realism-seed'));
  if (Number.isFinite(saved) && saved > 0) return saved;
  const created = Math.floor(Math.random() * 2_000_000_000) + 1;
  localStorage.setItem('club-input-realism-seed', String(created));
  return created;
}

export function createInputChatter(
  signal: ChatterSignal,
  fromHigh: boolean,
  toHigh: boolean,
  seed: number,
  startedAt = performance.now()
): ChatterTransition {
  const channel = signal === 'TC' ? 31 : signal === 'TG' ? 37 : 41;
  const base = signal === 'TC' ? 8 : signal === 'TG' ? 10 : 2;
  const spread = signal === 'TC' ? 6 : signal === 'TG' ? 8 : 4;
  return {
    startedAt,
    durationMs: base + unit(seed, channel) * spread,
    intervalMs: 1.2 + unit(seed, channel + 1) * 1.1,
    fromHigh,
    toHigh,
  };
}

function chatteredHigh(
  stableHigh: boolean,
  transition: ChatterTransition | undefined,
  now: number
) {
  if (!transition) return stableHigh;
  const elapsed = now - transition.startedAt;
  if (elapsed < 0 || elapsed >= transition.durationMs) return stableHigh;
  const phase = Math.floor(elapsed / transition.intervalMs);
  return phase % 2 === 0 ? transition.toHigh : transition.fromHigh;
}

function calibratedAxis(raw: number, seed: number, channel: number, now: number) {
  const centerOffset = (unit(seed, channel) * 2 - 1) * 11;
  const scale = 0.985 + unit(seed, channel + 1) * 0.03;
  const jitter = wave(seed, channel + 2, now) * 2.2;
  return clampRaw(512 + (raw - 512) * scale + centerOffset + jitter);
}

export function sampleRealisticInputVoltages({
  state,
  mapping,
  polarity,
  joystickDirection,
  encoderState,
  chatter,
  seed,
  now,
}: {
  state: RealismDeviceState;
  mapping: RealismInputMapping;
  polarity: Record<'TC' | 'TG' | 'PH' | 'PR' | 'ENC', 'HIGH' | 'LOW'>;
  joystickDirection: { X: 'RIGHT_MAX' | 'LEFT_MAX'; Y: 'UP_MAX' | 'DOWN_MAX' };
  encoderState: number;
  chatter: ChatterMap;
  seed: number;
  now: number;
}) {
  const voltages: Partial<Record<ArduinoTarget, number | null>> = {};
  const writeDigital = (signal: RealismSignal, high: boolean) => {
    voltages[mapping[signal]] = high ? 5 : 0;
  };
  const writeRaw = (signal: RealismSignal, raw: number) => {
    voltages[mapping[signal]] = rawVoltage(raw);
  };

  const activeLevel = (signal: 'TC' | 'TG' | 'PH', active: boolean) => active ? polarity[signal] === 'HIGH' : polarity[signal] === 'LOW';
  writeDigital('TC', chatteredHigh(activeLevel('TC', state.tcPressed), chatter.TC, now));
  writeDigital('TG', chatteredHigh(activeLevel('TG', state.tgHigh), chatter.TG, now));
  writeDigital('PH', chatteredHigh(activeLevel('PH', state.phTransparent), chatter.PH, now));

  const prOffset = (unit(seed, 1) * 2 - 1) * 8;
  const vrOffset = (unit(seed, 4) * 2 - 1) * 3;
  const prElectrical = polarity.PR === 'HIGH' ? state.prRaw : 1023 - state.prRaw;
  const prRaw = clampRaw(prElectrical + prOffset + wave(seed, 2, now) * 4);
  const vrRaw = clampRaw(state.vrRaw + vrOffset + wave(seed, 5, now) * 1.4);
  const joyXPhysical = joystickDirection.X === 'RIGHT_MAX' ? state.joyX : 1023 - state.joyX;
  const joyYPhysical = joystickDirection.Y === 'UP_MAX' ? state.joyY : 1023 - state.joyY;
  const joyX = calibratedAxis(joyXPhysical, seed, 8, now);
  const joyY = calibratedAxis(joyYPhysical, seed, 12, now);

  writeRaw('PR', prRaw);
  writeRaw('VR', vrRaw);
  writeRaw('JOYX', joyX);
  writeRaw('JOYY', joyY);

  const encAActive = Boolean(encoderState & 1);
  const encBActive = Boolean(encoderState & 2);
  writeDigital('ENCA', encAActive ? polarity.ENC === 'HIGH' : polarity.ENC === 'LOW');
  writeDigital('ENCB', encBActive ? polarity.ENC === 'HIGH' : polarity.ENC === 'LOW');

  let dsenRaw: number;
  if (state.dsenMm < DSEN_MIN_VALID_MM) {
    const nearLimit = dsenMmToRaw(DSEN_MIN_VALID_MM);
    dsenRaw = clampRaw(
      nearLimit +
        12 +
        wave(seed, 21, now) * 20 +
        wave(seed, 22, now * 1.37) * 7
    );
  } else {
    const staticMmOffset = (unit(seed, 20) * 2 - 1) * 3.5;
    const measuredMm = clamp(
      state.dsenMm + staticMmOffset + wave(seed, 23, now) * 1.6,
      DSEN_MIN_VALID_MM,
      DSEN_MAX_MM
    );
    dsenRaw = clampRaw(dsenMmToRaw(measuredMm) + wave(seed, 24, now) * 1.3);
  }
  writeRaw('DSEN', dsenRaw);

  return voltages;
}
