import { useCallback, useEffect, useRef, useState } from 'react';

export type SpeakerPermission = 'unknown' | 'allowed' | 'denied';

type AudioVoice = {
  source: AudioBufferSourceNode;
  gain: GainNode;
};

type AudioChain = {
  context: AudioContext;
  oscillator: OscillatorNode;
  speakerGain: GainNode;
  engineGain: GainNode;
  stepperGain: GainNode;
  engineBuffer: AudioBuffer | null;
  stepperBuffer: AudioBuffer | null;
  engineVoices: Set<AudioVoice>;
  stepperVoices: Set<AudioVoice>;
  engineScheduler: number | null;
  engineNextGrainTime: number;
  engineTargetRps: number;
  engineGrainIndex: number;
  stepperLastSimMs: number | null;
  stepperLastAudioTime: number;
};

const ENGINE_AUDIO_URL = './resources/F1V10mintomaxnew.wav';
const STEPPER_AUDIO_URL = './resources/STPM.wav';
const DCM_MAX_RPS = 2.4;

const ENGINE_GRAIN_SECONDS = 0.24;
const ENGINE_GRAIN_HOP_SECONDS = 0.019;
const ENGINE_LOOKAHEAD_SECONDS = 0.14;
const ENGINE_SCHEDULER_MS = 22;
const ENGINE_OFFSET_JITTER = [-0.009, 0.004, 0.011, -0.005, 0.007, -0.008, 0.002, 0.009];
const ENGINE_HOP_JITTER = [0, 0.0007, -0.0005, 0.0004, -0.0008, 0.0003];
const ENGINE_WINDOW = Float32Array.from({ length: 64 }, (_, index) => {
  const phase = index / 63;
  return Math.sin(Math.PI * phase) ** 2 * 0.11;
});
const STEPPER_OFFSET_SECONDS = 0.025;
const STEPPER_AUDIBLE_SECONDS = 0.24;

const readPermission = (): SpeakerPermission => {
  const saved = localStorage.getItem('club-spk-permission');
  return saved === 'allowed' || saved === 'denied' ? saved : 'unknown';
};

const readOutputEnabled = () => {
  const saved = localStorage.getItem('club-spk-output-enabled');
  if (saved === '1') return true;
  if (saved === '0') return false;
  return readPermission() === 'allowed';
};

const readVolume = (key: string) => {
  const saved = localStorage.getItem(key);
  if (saved === null) return 100;
  const value = Number(saved);
  return Number.isFinite(value) ? Math.max(0, Math.min(100, value)) : 100;
};

function stopVoiceSet(voices: Set<AudioVoice>, context: AudioContext, fadeSeconds: number) {
  const now = context.currentTime;
  for (const voice of voices) {
    voice.gain.gain.cancelScheduledValues(now);
    voice.gain.gain.setValueAtTime(voice.gain.gain.value, now);
    voice.gain.gain.linearRampToValueAtTime(0, now + fadeSeconds);
    try {
      voice.source.stop(now + fadeSeconds + 0.005);
    } catch {
      // Already stopped.
    }
  }
}

function stopEngine(audio: AudioChain) {
  audio.engineTargetRps = 0;
  audio.engineNextGrainTime = 0;
  if (audio.engineScheduler !== null) {
    window.clearInterval(audio.engineScheduler);
    audio.engineScheduler = null;
  }
  audio.engineGain.gain.setTargetAtTime(0, audio.context.currentTime, 0.02);
  stopVoiceSet(audio.engineVoices, audio.context, 0.022);
}

function stopStepper(audio: AudioChain) {
  audio.stepperLastSimMs = null;
  audio.stepperLastAudioTime = 0;
  stopVoiceSet(audio.stepperVoices, audio.context, 0.012);
}

function scheduleEngineGrain(audio: AudioChain, when: number) {
  const buffer = audio.engineBuffer;
  const rps = audio.engineTargetRps;
  if (!buffer || rps <= 0.015 || audio.context.state !== 'running') return;

  const normalized = Math.max(0, Math.min(1, rps / DCM_MAX_RPS));
  const usableStart = Math.min(0.3, Math.max(0.05, buffer.duration * 0.04));
  const usableEnd = Math.max(usableStart + ENGINE_GRAIN_SECONDS, buffer.duration - 0.3);
  const center = usableStart + normalized * Math.max(0.1, usableEnd - usableStart);
  const jitter = ENGINE_OFFSET_JITTER[audio.engineGrainIndex % ENGINE_OFFSET_JITTER.length];
  const maxOffset = Math.max(0.02, buffer.duration - ENGINE_GRAIN_SECONDS - 0.02);
  const offset = Math.max(0.02, Math.min(maxOffset, center - ENGINE_GRAIN_SECONDS / 2 + jitter));
  audio.engineGrainIndex += 1;

  const source = audio.context.createBufferSource();
  const gain = audio.context.createGain();
  const voice = { source, gain };
  source.buffer = buffer;
  source.playbackRate.value = 1;
  gain.gain.setValueCurveAtTime(ENGINE_WINDOW, when, ENGINE_GRAIN_SECONDS);
  source.connect(gain);
  gain.connect(audio.engineGain);
  audio.engineVoices.add(voice);
  source.onended = () => audio.engineVoices.delete(voice);
  source.start(when, offset, ENGINE_GRAIN_SECONDS);
}

function scheduleEngineAhead(audio: AudioChain) {
  if (!audio.engineBuffer || audio.engineTargetRps <= 0.015 || audio.context.state !== 'running') return;
  const now = audio.context.currentTime;
  if (audio.engineNextGrainTime < now + 0.006) audio.engineNextGrainTime = now + 0.008;
  const horizon = now + ENGINE_LOOKAHEAD_SECONDS;
  let guard = 0;
  while (audio.engineNextGrainTime < horizon && guard < 16) {
    scheduleEngineGrain(audio, audio.engineNextGrainTime);
    const hopJitter = ENGINE_HOP_JITTER[audio.engineGrainIndex % ENGINE_HOP_JITTER.length];
    audio.engineNextGrainTime += ENGINE_GRAIN_HOP_SECONDS + hopJitter;
    guard += 1;
  }
}

function updateEngineVoice(audio: AudioChain, rps: number, volume: number) {
  if (!audio.engineBuffer || rps <= 0.015 || volume <= 0) {
    stopEngine(audio);
    return;
  }

  const normalized = Math.max(0, Math.min(1, rps / DCM_MAX_RPS));
  audio.engineTargetRps = rps;
  audio.engineGain.gain.setTargetAtTime((0.25 + normalized * 0.06) * (volume / 100), audio.context.currentTime, 0.04);
  if (audio.engineScheduler !== null) return;

  audio.engineNextGrainTime = audio.context.currentTime + 0.008;
  scheduleEngineAhead(audio);
  audio.engineScheduler = window.setInterval(() => scheduleEngineAhead(audio), ENGINE_SCHEDULER_MS);
}

export function useSpeakerAudio(hz: number, dcmRps = 0) {
  const audioRef = useRef<AudioChain | null>(null);
  const engineLoadPromiseRef = useRef<Promise<AudioBuffer> | null>(null);
  const stepperLoadPromiseRef = useRef<Promise<AudioBuffer> | null>(null);
  const [permission, setPermission] = useState<SpeakerPermission>(readPermission);
  const [outputEnabled, setOutputEnabled] = useState(readOutputEnabled);
  const [ready, setReady] = useState(false);
  const [engineLoaded, setEngineLoaded] = useState(false);
  const [stepperLoaded, setStepperLoaded] = useState(false);
  const [dcmVolume, setDcmVolume] = useState(() => readVolume('club-audio-volume-dcm'));
  const [spkVolume, setSpkVolume] = useState(() => readVolume('club-audio-volume-spk'));
  const [stpmVolume, setStpmVolume] = useState(() => readVolume('club-audio-volume-stpm'));
  const [promptOpen, setPromptOpen] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => { localStorage.setItem('club-audio-volume-dcm', String(dcmVolume)); }, [dcmVolume]);
  useEffect(() => { localStorage.setItem('club-audio-volume-spk', String(spkVolume)); }, [spkVolume]);
  useEffect(() => { localStorage.setItem('club-audio-volume-stpm', String(stpmVolume)); }, [stpmVolume]);

  const muteNow = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.speakerGain.gain.setTargetAtTime(0, audio.context.currentTime, 0.006);
    stopEngine(audio);
    stopStepper(audio);
  }, []);

  const ensureEngineBuffer = useCallback(async (audio: AudioChain) => {
    if (audio.engineBuffer) return audio.engineBuffer;
    if (!engineLoadPromiseRef.current) {
      engineLoadPromiseRef.current = fetch(`${ENGINE_AUDIO_URL}?rev=4`, { cache: 'no-store' })
        .then(response => {
          if (!response.ok) throw new Error(`DCM音源を読み込めませんでした (${response.status})`);
          return response.arrayBuffer();
        })
        .then(arrayBuffer => audio.context.decodeAudioData(arrayBuffer));
    }
    try {
      const buffer = await engineLoadPromiseRef.current;
      audio.engineBuffer = buffer;
      setEngineLoaded(true);
      return buffer;
    } catch (caught) {
      engineLoadPromiseRef.current = null;
      setEngineLoaded(false);
      throw caught;
    }
  }, []);

  const ensureStepperBuffer = useCallback(async (audio: AudioChain) => {
    if (audio.stepperBuffer) return audio.stepperBuffer;
    if (!stepperLoadPromiseRef.current) {
      stepperLoadPromiseRef.current = fetch(`${STEPPER_AUDIO_URL}?rev=1`, { cache: 'no-store' })
        .then(response => {
          if (!response.ok) throw new Error(`STPM音源を読み込めませんでした (${response.status})`);
          return response.arrayBuffer();
        })
        .then(arrayBuffer => audio.context.decodeAudioData(arrayBuffer));
    }
    try {
      const buffer = await stepperLoadPromiseRef.current;
      audio.stepperBuffer = buffer;
      setStepperLoaded(true);
      return buffer;
    } catch (caught) {
      stepperLoadPromiseRef.current = null;
      setStepperLoaded(false);
      throw caught;
    }
  }, []);

  const ensureAudio = useCallback(async () => {
    try {
      let audio = audioRef.current;
      if (!audio) {
        const context = new AudioContext();
        const oscillator = context.createOscillator();
        const speakerGain = context.createGain();
        const engineGain = context.createGain();
        const stepperGain = context.createGain();
        oscillator.type = 'square';
        oscillator.frequency.value = 440;
        speakerGain.gain.value = 0;
        engineGain.gain.value = 0;
        stepperGain.gain.value = 0;
        oscillator.connect(speakerGain);
        speakerGain.connect(context.destination);
        engineGain.connect(context.destination);
        stepperGain.connect(context.destination);
        oscillator.start();
        audio = {
          context,
          oscillator,
          speakerGain,
          engineGain,
          stepperGain,
          engineBuffer: null,
          stepperBuffer: null,
          engineVoices: new Set(),
          stepperVoices: new Set(),
          engineScheduler: null,
          engineNextGrainTime: 0,
          engineTargetRps: 0,
          engineGrainIndex: 0,
          stepperLastSimMs: null,
          stepperLastAudioTime: 0,
        };
        audioRef.current = audio;
      }
      if (audio.context.state !== 'running') await audio.context.resume();
      const running = audio.context.state === 'running';
      setReady(running);
      if (!running) throw new Error('ブラウザの音声再生が停止中です。PHONE AUDIOをもう一度タップしてください。');
      setError('');
      void ensureEngineBuffer(audio).catch(caught => {
        setError(caught instanceof Error ? caught.message : 'DCMエンジン音を読み込めませんでした。');
      });
      void ensureStepperBuffer(audio).catch(caught => {
        setError(caught instanceof Error ? caught.message : 'STPM音を読み込めませんでした。');
      });
    } catch (caught) {
      setReady(false);
      setError(caught instanceof Error ? caught.message : '端末音声を開始できませんでした。');
    }
  }, [ensureEngineBuffer, ensureStepperBuffer]);

  const allow = useCallback(async () => {
    localStorage.setItem('club-spk-permission', 'allowed');
    localStorage.setItem('club-spk-output-enabled', '1');
    setPermission('allowed');
    setOutputEnabled(true);
    setPromptOpen(false);
    await ensureAudio();
  }, [ensureAudio]);

  const activate = useCallback(async () => {
    if (permission !== 'allowed' || !outputEnabled) return;
    await ensureAudio();
  }, [ensureAudio, outputEnabled, permission]);

  const deny = useCallback(() => {
    localStorage.setItem('club-spk-permission', 'denied');
    localStorage.setItem('club-spk-output-enabled', '0');
    setPermission('denied');
    setOutputEnabled(false);
    setPromptOpen(false);
    muteNow();
  }, [muteNow]);

  const requestPermission = useCallback(() => {
    setPromptOpen(true);
  }, []);

  const toggleOutput = useCallback(async () => {
    if (permission !== 'allowed') {
      setPromptOpen(true);
      return;
    }
    if (outputEnabled) {
      localStorage.setItem('club-spk-output-enabled', '0');
      setOutputEnabled(false);
      muteNow();
      return;
    }
    localStorage.setItem('club-spk-output-enabled', '1');
    setOutputEnabled(true);
    await ensureAudio();
  }, [ensureAudio, muteNow, outputEnabled, permission]);

  const playStepperStep = useCallback((simMs: number) => {
    const audio = audioRef.current;
    if (!audio || !audio.stepperBuffer || audio.context.state !== 'running' || permission !== 'allowed' || !outputEnabled || stpmVolume <= 0) return;

    const now = audio.context.currentTime;
    let when = now + 0.003;
    if (audio.stepperLastSimMs !== null && simMs > audio.stepperLastSimMs) {
      const delta = (simMs - audio.stepperLastSimMs) / 1000;
      if (delta < 0.3) {
        const predicted = audio.stepperLastAudioTime + Math.max(0.001, delta);
        when = Math.max(now + 0.002, predicted);
        if (when - now > 0.14) when = now + 0.004;
      }
    }
    audio.stepperLastSimMs = simMs;
    audio.stepperLastAudioTime = when;

    const buffer = audio.stepperBuffer;
    const offset = Math.min(STEPPER_OFFSET_SECONDS, Math.max(0, buffer.duration - 0.05));
    const duration = Math.min(STEPPER_AUDIBLE_SECONDS, Math.max(0.03, buffer.duration - offset));
    const source = audio.context.createBufferSource();
    const gain = audio.context.createGain();
    const voice = { source, gain };
    source.buffer = buffer;
    gain.gain.setValueAtTime(0, when);
    gain.gain.linearRampToValueAtTime(0.16, when + 0.003);
    gain.gain.setValueAtTime(0.16, when + Math.max(0.004, duration - 0.025));
    gain.gain.linearRampToValueAtTime(0, when + duration);
    source.connect(gain);
    gain.connect(audio.stepperGain);
    audio.stepperVoices.add(voice);
    source.onended = () => audio.stepperVoices.delete(voice);
    source.start(when, offset, duration);
  }, [outputEnabled, permission, stpmVolume]);

  useEffect(() => {
    if (permission !== 'allowed' || !outputEnabled || ready) return;
    const unlock = () => {
      void ensureAudio();
    };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('touchstart', unlock, { once: true, passive: true });
    window.addEventListener('keydown', unlock, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('touchstart', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, [ensureAudio, outputEnabled, permission, ready]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !ready || permission !== 'allowed' || !outputEnabled) {
      muteNow();
      return;
    }
    const now = audio.context.currentTime;
    if (hz >= 20 && hz <= 12000 && spkVolume > 0) {
      audio.oscillator.frequency.setTargetAtTime(hz, now, 0.003);
      audio.speakerGain.gain.setTargetAtTime(0.085 * (spkVolume / 100), now, 0.008);
    } else {
      audio.speakerGain.gain.setTargetAtTime(0, now, 0.008);
    }
  }, [hz, muteNow, outputEnabled, permission, ready, spkVolume]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !ready || !engineLoaded || permission !== 'allowed' || !outputEnabled) {
      if (audio) updateEngineVoice(audio, 0, dcmVolume);
      return;
    }
    updateEngineVoice(audio, Math.abs(dcmRps), dcmVolume);
  }, [dcmRps, dcmVolume, engineLoaded, outputEnabled, permission, ready]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.stepperGain.gain.setTargetAtTime(0.65 * (stpmVolume / 100), audio.context.currentTime, 0.018);
  }, [ready, stpmVolume]);

  useEffect(
    () => () => {
      const audio = audioRef.current;
      if (!audio) return;
      stopEngine(audio);
      stopStepper(audio);
      try {
        audio.oscillator.stop();
      } catch {
        // Already stopped.
      }
      void audio.context.close();
      audioRef.current = null;
    },
    []
  );

  return {
    permission,
    outputEnabled,
    ready,
    engineLoaded,
    stepperLoaded,
    dcmVolume,
    spkVolume,
    stpmVolume,
    setDcmVolume,
    setSpkVolume,
    setStpmVolume,
    promptOpen,
    error,
    allow,
    activate,
    deny,
    requestPermission,
    toggleOutput,
    playStepperStep,
  };
}
