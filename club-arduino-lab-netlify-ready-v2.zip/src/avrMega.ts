import {
  ADCMuxInputType,
  AVRADC,
  AVRIOPort,
  AVRTimer,
  AVRUSART,
  CPU,
  PinState,
  adcConfig,
  avrInstruction,
  portAConfig,
  portBConfig,
  portCConfig,
  portDConfig,
  portEConfig,
  portFConfig,
  portGConfig,
  portHConfig,
  portJConfig,
  portKConfig,
  portLConfig,
  timer0Config,
  timer1Config,
  timer2Config,
  usart0Config,
} from 'avr8js';
import { provisionalDcmRps } from './sim';
import type { ArduinoTarget } from './sim';

const CLOCK_HZ = 16_000_000;
const FLASH_BYTES = 0x40000;
const DATA_BYTES = 0x2200;

export type HexiResult = {
  stdout?: string;
  stderr?: string;
  hex?: string;
};

export type MegaSnapshot = {
  cycles: number;
  simMs: number;
  pc: number;
  porta: number;
  ddra: number;
  d11: 'LOW' | 'HIGH' | 'INPUT' | 'PULLUP';
  d12: 'LOW' | 'HIGH' | 'INPUT' | 'PULLUP';
  pwm11: number;
  pwm12: number;
  pwm44: number;
  pwm45: number;
  pwm46: number;
  out11: number;
  out12: number;
  out44: number;
  out45: number;
  out46: number;
  dcmRps: number;
  dcmAngle: number;
  dcmMode: 'drive' | 'brake' | 'coast' | 'mixed';
  dcmDirection: -1 | 0 | 1;
  dcmCommandSpeed: number;
  phoHigh: boolean;
  phoDropped: number;
  stpmAngle: number;
  stpmMissed: number;
  segBytes: [number, number, number];
  buzzerHz: number;
};

export async function buildMegaHex(source: string): Promise<HexiResult> {
  let lastError: unknown = null;

  for (let attempt = 1; attempt <= 3; attempt += 1) {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 18000);
    try {
      const response = await fetch('https://hexi.wokwi.com/build', {
        method: 'POST',
        mode: 'cors',
        cache: 'no-cache',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sketch: source, board: 'mega' }),
        signal: controller.signal,
      });
      if (response.ok) return (await response.json()) as HexiResult;
      const retryable = response.status === 429 || response.status >= 500;
      if (!retryable) throw new Error(`コンパイラHTTP ${response.status}`);
      lastError = new Error(`コンパイラHTTP ${response.status}`);
    } catch (error) {
      lastError = error;
      const permanentHttpError = error instanceof Error && /コンパイラHTTP 4\d\d/.test(error.message) && !error.message.includes('429');
      if (permanentHttpError) throw error;
    } finally {
      window.clearTimeout(timeout);
    }

    if (attempt < 3) await new Promise(resolve => window.setTimeout(resolve, 350 * attempt));
  }

  if (lastError instanceof DOMException && lastError.name === 'AbortError') {
    throw new Error('コンパイラ応答がタイムアウトしました。再度実行してください。');
  }
  if (lastError instanceof Error) throw new Error(`コンパイラ接続に失敗しました: ${lastError.message}`);
  throw new Error('コンパイラ接続に失敗しました。');
}

function loadIntelHex(source: string, target: Uint8Array) {
  let baseAddress = 0;
  for (const rawLine of source.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line.startsWith(':') || line.length < 11) continue;
    const length = Number.parseInt(line.slice(1, 3), 16);
    const address = Number.parseInt(line.slice(3, 7), 16);
    const recordType = Number.parseInt(line.slice(7, 9), 16);
    const data = line.slice(9, 9 + length * 2);
    if (recordType === 0x00) {
      const absolute = baseAddress + address;
      for (let i = 0; i < length; i += 1) {
        const index = absolute + i;
        if (index >= 0 && index < target.length) {
          target[index] = Number.parseInt(data.slice(i * 2, i * 2 + 2), 16);
        }
      }
    } else if (recordType === 0x02) {
      baseAddress = Number.parseInt(data, 16) << 4;
    } else if (recordType === 0x04) {
      baseAddress = Number.parseInt(data, 16) << 16;
    }
  }
}

const ext = (index: number, eicr: number, iscOffset: number, interrupt: number) => ({
  EICR: eicr,
  EIMSK: 0x3d,
  EIFR: 0x3c,
  iscOffset,
  index,
  interrupt,
});

const megaPortDConfig = {
  ...portDConfig,
  pinChange: undefined,
  externalInterrupts: [
    ext(0, 0x69, 0, 0x02),
    ext(1, 0x69, 2, 0x04),
    ext(2, 0x69, 4, 0x06),
    ext(3, 0x69, 6, 0x08),
  ],
};

const megaPortEConfig = {
  ...portEConfig,
  externalInterrupts: [
    null,
    null,
    null,
    null,
    ext(4, 0x6a, 0, 0x0a),
    ext(5, 0x6a, 2, 0x0c),
    ext(6, 0x6a, 4, 0x0e),
    ext(7, 0x6a, 6, 0x10),
  ],
};

const megaPortCConfig = { ...portCConfig, pinChange: undefined };

const megaTimer0 = {
  ...timer0Config,
  compAInterrupt: 0x2a,
  compBInterrupt: 0x2c,
  ovfInterrupt: 0x2e,
  compPortA: portBConfig.PORT,
  compPinA: 7,
  compPortB: portGConfig.PORT,
  compPinB: 5,
  externalClockPort: megaPortDConfig.PORT,
  externalClockPin: 7,
};

const megaTimer1 = {
  ...timer1Config,
  captureInterrupt: 0x20,
  compAInterrupt: 0x22,
  compBInterrupt: 0x24,
  compCInterrupt: 0x26,
  ovfInterrupt: 0x28,
  compPortA: portBConfig.PORT,
  compPinA: 5,
  compPortB: portBConfig.PORT,
  compPinB: 6,
  compPortC: portBConfig.PORT,
  compPinC: 7,
  externalClockPort: megaPortDConfig.PORT,
  externalClockPin: 6,
};

const megaTimer2 = {
  ...timer2Config,
  compAInterrupt: 0x1a,
  compBInterrupt: 0x1c,
  ovfInterrupt: 0x1e,
  compPortA: portBConfig.PORT,
  compPinA: 4,
  compPortB: portHConfig.PORT,
  compPinB: 6,
};

const megaTimer5 = {
  bits: 16 as const,
  captureInterrupt: 0x5c,
  compAInterrupt: 0x5e,
  compBInterrupt: 0x60,
  compCInterrupt: 0x62,
  ovfInterrupt: 0x64,
  TIFR: 0x3a,
  OCRA: 0x128,
  OCRB: 0x12a,
  OCRC: 0x12c,
  ICR: 0x126,
  TCNT: 0x124,
  TCCRA: 0x120,
  TCCRB: 0x121,
  TCCRC: 0x122,
  TIMSK: 0x73,
  TOV: 1,
  OCFA: 2,
  OCFB: 4,
  OCFC: 8,
  TOIE: 1,
  OCIEA: 2,
  OCIEB: 4,
  OCIEC: 8,
  dividers: { 0: 0, 1: 1, 2: 8, 3: 64, 4: 256, 5: 1024, 6: 0, 7: 0 },
  compPortA: portLConfig.PORT,
  compPinA: 3,
  compPortB: portLConfig.PORT,
  compPinB: 4,
  compPortC: portLConfig.PORT,
  compPinC: 5,
  externalClockPort: portLConfig.PORT,
  externalClockPin: 2,
};

const megaMuxChannels = {
  0x00: { type: ADCMuxInputType.SingleEnded, channel: 0 },
  0x01: { type: ADCMuxInputType.SingleEnded, channel: 1 },
  0x02: { type: ADCMuxInputType.SingleEnded, channel: 2 },
  0x03: { type: ADCMuxInputType.SingleEnded, channel: 3 },
  0x04: { type: ADCMuxInputType.SingleEnded, channel: 4 },
  0x05: { type: ADCMuxInputType.SingleEnded, channel: 5 },
  0x06: { type: ADCMuxInputType.SingleEnded, channel: 6 },
  0x07: { type: ADCMuxInputType.SingleEnded, channel: 7 },
  0x20: { type: ADCMuxInputType.SingleEnded, channel: 8 },
  0x21: { type: ADCMuxInputType.SingleEnded, channel: 9 },
  0x22: { type: ADCMuxInputType.SingleEnded, channel: 10 },
  0x23: { type: ADCMuxInputType.SingleEnded, channel: 11 },
  0x24: { type: ADCMuxInputType.SingleEnded, channel: 12 },
  0x25: { type: ADCMuxInputType.SingleEnded, channel: 13 },
  0x26: { type: ADCMuxInputType.SingleEnded, channel: 14 },
  0x27: { type: ADCMuxInputType.SingleEnded, channel: 15 },
};

const megaAdcConfig = {
  ...adcConfig,
  adcInterrupt: 0x3a,
  numChannels: 16,
  muxInputMask: 0x3f,
  muxChannels: megaMuxChannels,
};

const megaUsart0Config = {
  ...usart0Config,
  rxCompleteInterrupt: 0x32,
  dataRegisterEmptyInterrupt: 0x34,
  txCompleteInterrupt: 0x36,
};

function pinLabel(state: PinState): MegaSnapshot['d11'] {
  if (state === PinState.High) return 'HIGH';
  if (state === PinState.Low) return 'LOW';
  if (state === PinState.InputPullUp) return 'PULLUP';
  return 'INPUT';
}

export class MegaRunner {
  readonly program = new Uint16Array(FLASH_BYTES / 2);
  readonly cpu: CPU;
  readonly adc: AVRADC;
  readonly usart: AVRUSART;
  readonly ports: Record<string, AVRIOPort>;
  private running = false;
  private raf = 0;
  private previousWallTime = 0;
  private physicsCycle = 0;
  private dcmRps = 0;
  private dcmAngle = 30;
  private dcmMode: MegaSnapshot['dcmMode'] = 'coast';
  private dcmCommandSpeed = 0;
  private phoHigh = false;
  private phoDropped = 0;
  private stpmAngle = 0;
  private stpmMissed = 0;
  private lastStepperPhase = 0;
  private segShift = 0;
  private segBits = 0;
  private segBytes: [number, number, number] = [0, 0, 0];
  private buzzerEdges: number[] = [];
  onSerialByte: ((value: number) => void) | null = null;
  onStepperStep: ((simMs: number) => void) | null = null;

  constructor(hex: string) {
    loadIntelHex(hex, new Uint8Array(this.program.buffer));
    this.cpu = new CPU(this.program, DATA_BYTES);
    this.ports = {
      A: new AVRIOPort(this.cpu, portAConfig),
      B: new AVRIOPort(this.cpu, portBConfig),
      C: new AVRIOPort(this.cpu, megaPortCConfig),
      D: new AVRIOPort(this.cpu, megaPortDConfig),
      E: new AVRIOPort(this.cpu, megaPortEConfig),
      F: new AVRIOPort(this.cpu, portFConfig),
      G: new AVRIOPort(this.cpu, portGConfig),
      H: new AVRIOPort(this.cpu, portHConfig),
      J: new AVRIOPort(this.cpu, portJConfig),
      K: new AVRIOPort(this.cpu, portKConfig),
      L: new AVRIOPort(this.cpu, portLConfig),
    };
    new AVRTimer(this.cpu, megaTimer0);
    new AVRTimer(this.cpu, megaTimer1);
    new AVRTimer(this.cpu, megaTimer2);
    new AVRTimer(this.cpu, megaTimer5);
    this.adc = new AVRADC(this.cpu, megaAdcConfig);
    this.usart = new AVRUSART(this.cpu, megaUsart0Config, CLOCK_HZ);
    this.usart.onByteTransmit = value => this.onSerialByte?.(value);
    this.ports.A.addListener(value => this.trackStepper(value));
    this.ports.L.addListener((value, oldValue) => this.trackPortL(value, oldValue));
    this.ports.H.setPin(1, false);
  }

  syncInputs(voltages: Partial<Record<ArduinoTarget, number | null>>) {
    const digital: Array<[ArduinoTarget, string, number]> = [
      ['D1', 'E', 1],
      ['D3', 'E', 5],
      ['D5', 'E', 3],
      ['D7', 'H', 4],
      ['D9', 'H', 6],
      ['D20', 'D', 1],
      ['D21', 'D', 0],
    ];
    digital.forEach(([target, portName, bit]) => {
      const voltage = voltages[target];
      if (typeof voltage === 'number') {
        this.ports[portName].setPin(bit, voltage >= 3.0);
      }
    });
    const analog: Array<[ArduinoTarget, number]> = [
      ['A2', 2],
      ['A4', 4],
      ['A6', 6],
      ['A8', 8],
      ['A10', 10],
    ];
    analog.forEach(([target, channel]) => {
      const voltage = voltages[target];
      this.adc.channelValues[channel] = typeof voltage === 'number' ? voltage : 0;
    });
  }

  private read16(address: number) {
    return this.cpu.data[address] | (this.cpu.data[address + 1] << 8);
  }

  private analogOut(portName: string, bit: number, tccra: number, comMask: number, ocr: number) {
    if ((this.cpu.data[tccra] & comMask) !== 0) return Math.min(255, this.read16(ocr) & 0xff);
    const state = this.ports[portName].pinState(bit);
    return state === PinState.High || state === PinState.InputPullUp ? 255 : 0;
  }

  private trackStepper(value: number) {
    if ((this.cpu.data[portAConfig.DDR] & 0x0f) !== 0x0f) return;
    const phase = [1, 2, 4, 8].indexOf(value & 0x0f);
    if (phase < 0 || phase === this.lastStepperPhase) return;
    const diff = (phase - this.lastStepperPhase + 4) % 4;
    let stepped = false;
    if (diff === 1) {
      this.stpmAngle = (this.stpmAngle + 3) % 360;
      stepped = true;
    } else if (diff === 3) {
      this.stpmAngle = (this.stpmAngle + 357) % 360;
      stepped = true;
    } else {
      this.stpmMissed += 1;
    }
    this.lastStepperPhase = phase;
    if (stepped) this.onStepperStep?.((this.cpu.cycles / CLOCK_HZ) * 1000);
  }

  private trackPortL(value: number, oldValue: number) {
    const ddrl = this.cpu.data[portLConfig.DDR];
    if ((ddrl & 0x07) === 0x07) {
      const latch = value & 1;
      const oldLatch = oldValue & 1;
      const clock = value & 4;
      const oldClock = oldValue & 4;
      if (oldLatch && !latch) {
        this.segShift = 0;
        this.segBits = 0;
      }
      if (!oldClock && clock && !latch) {
        const dataBit = (value >> 1) & 1;
        this.segShift = ((this.segShift << 1) | dataBit) & 0xffffff;
        this.segBits = Math.min(24, this.segBits + 1);
      }
      if (!oldLatch && latch && this.segBits > 0) {
        this.segBytes = [
          (this.segShift >> 16) & 0xff,
          (this.segShift >> 8) & 0xff,
          this.segShift & 0xff,
        ];
      }
    }
    const buzzer = value & 0x40;
    const oldBuzzer = oldValue & 0x40;
    if ((ddrl & 0x40) !== 0 && !oldBuzzer && buzzer) {
      this.buzzerEdges.push(this.cpu.cycles);
      if (this.buzzerEdges.length > 8) this.buzzerEdges.shift();
    }
  }

  private motorDrive() {
    const a = this.analogOut('B', 5, 0x80, 0xc0, 0x88);
    const b = this.analogOut('B', 6, 0x80, 0x30, 0x8a);
    if (a >= 254 && b >= 254) return { mode: 'brake' as const, direction: 0 as const, speed: 0 };
    if (a <= 1 && b <= 1) return { mode: 'coast' as const, direction: 0 as const, speed: 0 };
    if (a >= 254) return { mode: 'drive' as const, direction: 1 as const, speed: b };
    if (b >= 254) return { mode: 'drive' as const, direction: -1 as const, speed: a };
    if (a === b) return { mode: 'mixed' as const, direction: 0 as const, speed: 0 };
    return { mode: 'mixed' as const, direction: (a > b ? 1 : -1) as -1 | 1, speed: Math.min(a, b) };
  }

  private tickPhysics(cycles: number) {
    const dt = cycles / CLOCK_HZ;
    const drive = this.motorDrive();
    this.dcmMode = drive.mode;
    this.dcmCommandSpeed = drive.speed;
    if (drive.mode === 'brake') {
      this.dcmRps = 0;
    } else if (drive.mode === 'coast') {
      this.dcmRps *= Math.exp(-dt / 0.15);
    } else {
      const target = drive.direction * provisionalDcmRps(drive.speed);
      const alpha = 1 - Math.exp(-dt / 0.015);
      this.dcmRps += (target - this.dcmRps) * alpha;
    }
    if (Math.abs(this.dcmRps) < 0.002) this.dcmRps = 0;
    this.dcmAngle = (this.dcmAngle + this.dcmRps * 360 * dt + 360) % 360;

    const phase = ((this.dcmAngle % 60) + 60) % 60;
    const holeNow = phase < 18;
    this.phoHigh = holeNow;
    this.ports.H.setPin(1, this.phoHigh);
  }

  private buzzerFrequency() {
    if ((this.cpu.data[portLConfig.DDR] & 0x40) === 0 || this.buzzerEdges.length < 2) return 0;
    const last = this.buzzerEdges[this.buzzerEdges.length - 1];
    const first = this.buzzerEdges[0];
    const periods = this.buzzerEdges.length - 1;
    const averageCycles = (last - first) / periods;
    if (averageCycles <= 0) return 0;
    const staleCycles = Math.max(CLOCK_HZ * 0.02, averageCycles * 3);
    if (this.cpu.cycles - last > staleCycles) return 0;
    return CLOCK_HZ / averageCycles;
  }

  snapshot(): MegaSnapshot {
    return {
      cycles: this.cpu.cycles,
      simMs: (this.cpu.cycles / CLOCK_HZ) * 1000,
      pc: this.cpu.pc,
      porta: this.cpu.data[portAConfig.PORT],
      ddra: this.cpu.data[portAConfig.DDR],
      d11: pinLabel(this.ports.B.pinState(5)),
      d12: pinLabel(this.ports.B.pinState(6)),
      pwm11: this.read16(0x88),
      pwm12: this.read16(0x8a),
      pwm44: this.read16(0x12c),
      pwm45: this.read16(0x12a),
      pwm46: this.read16(0x128),
      out11: this.analogOut('B', 5, 0x80, 0xc0, 0x88),
      out12: this.analogOut('B', 6, 0x80, 0x30, 0x8a),
      out44: this.analogOut('L', 5, 0x120, 0x0c, 0x12c),
      out45: this.analogOut('L', 4, 0x120, 0x30, 0x12a),
      out46: this.analogOut('L', 3, 0x120, 0xc0, 0x128),
      dcmRps: Math.abs(this.dcmRps),
      dcmAngle: this.dcmAngle,
      dcmMode: this.dcmMode,
      dcmDirection: this.dcmRps > 0.01 ? 1 : this.dcmRps < -0.01 ? -1 : 0,
      dcmCommandSpeed: this.dcmCommandSpeed,
      phoHigh: this.phoHigh,
      phoDropped: this.phoDropped,
      stpmAngle: this.stpmAngle,
      stpmMissed: this.stpmMissed,
      segBytes: [...this.segBytes] as [number, number, number],
      buzzerHz: this.buzzerFrequency(),
    };
  }

  start(onFrame: (snapshot: MegaSnapshot) => void) {
    this.stop();
    this.running = true;
    this.previousWallTime = performance.now();
    this.physicsCycle = this.cpu.cycles;
    let lastPublishWallTime = 0;
    const frame = (now: number) => {
      if (!this.running) return;
      const elapsedMs = Math.min(20, Math.max(1, now - this.previousWallTime));
      this.previousWallTime = now;
      const cycleBudget = Math.min(320_000, Math.round(elapsedMs * (CLOCK_HZ / 1000)));
      const target = this.cpu.cycles + cycleBudget;
      const workStarted = performance.now();
      let instructions = 0;
      while (this.cpu.cycles < target) {
        avrInstruction(this.cpu);
        this.cpu.tick();
        instructions += 1;
        if (this.cpu.cycles - this.physicsCycle >= 16_000) {
          const delta = this.cpu.cycles - this.physicsCycle;
          this.tickPhysics(delta);
          this.physicsCycle = this.cpu.cycles;
        }
        if ((instructions & 2047) === 0 && performance.now() - workStarted > 4.5) break;
      }
      if (lastPublishWallTime === 0 || now - lastPublishWallTime >= 50) {
        onFrame(this.snapshot());
        lastPublishWallTime = now;
      }
      this.raf = requestAnimationFrame(frame);
    };
    this.raf = requestAnimationFrame(frame);
  }

  stop() {
    this.running = false;
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
  }
}
