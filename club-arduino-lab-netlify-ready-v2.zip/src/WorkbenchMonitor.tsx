import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent, type ReactNode } from 'react';
import { Cable, RotateCcw, X } from 'lucide-react';
import type { ArduinoTarget } from './sim';

export type InputSignal = 'TC' | 'TG' | 'PH' | 'PR' | 'VR' | 'JOYX' | 'JOYY' | 'ENCA' | 'ENCB' | 'DSEN';
export type ActivePolaritySignal = 'TC' | 'TG' | 'PH' | 'PR' | 'ENC';
export type ActivePolarity = 'HIGH' | 'LOW';
export type InputPolarity = Record<ActivePolaritySignal, ActivePolarity>;
export type JoystickDirection = { X: 'RIGHT_MAX' | 'LEFT_MAX'; Y: 'UP_MAX' | 'DOWN_MAX' }; 

export type DeviceState = {
  tcPressed: boolean;
  tgHigh: boolean;
  phTransparent: boolean;
  prRaw: number;
  vrRaw: number;
  joyX: number;
  joyY: number;
  dsenRaw: number;
};

export type MeasuredInputs = {
  tcHigh: boolean;
  tgHigh: boolean;
  phHigh: boolean;
  prRaw: number;
  vrRaw: number;
  joyX: number;
  joyY: number;
  dsenRaw: number;
  dsenError: boolean;
};

export const defaultDeviceState: DeviceState = {
  tcPressed: false,
  tgHigh: false,
  phTransparent: true,
  prRaw: 0,
  vrRaw: 512,
  joyX: 512,
  joyY: 512,
  dsenRaw: 512,
};

export const digitalArduinoTargets: ArduinoTarget[] = ['D1', 'D3', 'D5', 'D7', 'D9', 'D20', 'D21'];
export const analogArduinoTargets: ArduinoTarget[] = ['A2', 'A4', 'A6', 'A8', 'A10'];
export const defaultInputMapping: Record<InputSignal, ArduinoTarget> = {
  TC: 'D1', TG: 'D3', PH: 'D5', PR: 'A2', VR: 'A4', JOYX: 'A6', JOYY: 'A8', ENCA: 'D20', ENCB: 'D21', DSEN: 'A10',
};
export const defaultInputPolarity: InputPolarity = { TC: 'LOW', TG: 'HIGH', PH: 'HIGH', PR: 'LOW', ENC: 'HIGH' };
export const defaultJoystickDirection: JoystickDirection = { X: 'RIGHT_MAX', Y: 'UP_MAX' }; 

export const DSEN_UI_MIN_MM = 20;
export const DSEN_MIN_VALID_MM = 30;
export const DSEN_MAX_MM = 200;
export const dsenRawToMm = (raw: number) => Math.round(Math.max(DSEN_UI_MIN_MM, Math.min(DSEN_MAX_MM, 730 - raw * 1.3)));
export const dsenMmToRaw = (mm: number) => Math.round(Math.max(0, Math.min(1023, (730 - mm) / 1.3)));

const connectorPins: Record<InputSignal, number> = { TC: 3, TG: 4, PH: 5, PR: 6, VR: 7, JOYX: 8, JOYY: 9, ENCA: 10, ENCB: 11, DSEN: 12 };
const labels: Record<InputSignal, string> = { TC: 'TC', TG: 'TG', PH: 'PH', PR: 'PR', VR: 'VR', JOYX: 'JOY X', JOYY: 'JOY Y', ENCA: 'ENC A', ENCB: 'ENC B', DSEN: 'DSEN' };
const digitalSignals: InputSignal[] = ['TC', 'TG', 'PH', 'ENCA', 'ENCB'];
const analogSignals: InputSignal[] = ['PR', 'VR', 'JOYX', 'JOYY', 'DSEN'];
const polaritySignals: ActivePolaritySignal[] = ['TC', 'TG', 'PH', 'PR', 'ENC'];
const polarityNames: Record<ActivePolaritySignal, string> = { TC: 'TC 押下', TG: 'TG ON', PH: 'PH 透過', PR: 'PR 反射', ENC: 'ENC A/B 相' };
const percent = (value: number) => Math.round((Math.max(0, Math.min(1023, value)) / 1023) * 100);

function PinBadge({ signal, mapping }: { signal: InputSignal; mapping: Record<InputSignal, ArduinoTarget> }) {
  return <span className="device-pin-badge mono" title={`${labels[signal]}: コネクタP${connectorPins[signal]} → ${mapping[signal]}`}>P{connectorPins[signal]}→{mapping[signal]}</span>;
}

function LogicBadge({ high }: { high: boolean }) {
  return (
    <span className={`logic-badge ${high ? 'is-high' : 'is-low'}`}>
      <span className="logic-led" />{high ? 'HIGH' : 'LOW'}
    </span>
  );
}

function TactileGraphic({ pressed }: { pressed: boolean }) {
  return (
    <div className={`relative mx-auto h-8 w-9 rounded-lg border p-0.5 shadow-inner ${pressed ? 'border-[#54bcc5] bg-[#9fb9ba]' : 'border-[#887b69] bg-[#b7afa3]'}`}>
      <span className="absolute left-1 top-1 h-1 w-1 rounded-full bg-[#645f57]/65" />
      <span className="absolute right-1 top-1 h-1 w-1 rounded-full bg-[#645f57]/65" />
      <span className="absolute bottom-1 left-1 h-1 w-1 rounded-full bg-[#645f57]/65" />
      <span className="absolute bottom-1 right-1 h-1 w-1 rounded-full bg-[#645f57]/65" />
      <div
        className={`device-metal absolute left-1/2 h-[18px] w-[18px] -translate-x-1/2 rounded-[5px] border transition-all ${pressed ? 'border-[#61d7db] shadow-[0_0_8px_rgba(53,197,203,.38)]' : 'border-[#817d76] shadow-sm'}`}
        style={{ top: pressed ? 7 : 3 }}
      >
        <div className="absolute inset-[4px] rounded-[3px] bg-[#f3f2ed]/80" />
      </div>
    </div>
  );
}

function ToggleGraphic({ high }: { high: boolean }) {
  return (
    <div className="device-metal relative mx-auto h-8 w-9 rounded-lg border border-[#827867] shadow-inner">
      <div className="absolute inset-x-1 bottom-1 h-1 rounded-full bg-[#655f56]/30" />
      <div className="absolute left-1/2 top-[18px] h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#756f65] bg-[#eeeae1] shadow-inner" />
      <div
        className="absolute left-1/2 top-[18px] h-[17px] w-[4px] origin-bottom rounded-full border border-[#515d61] bg-gradient-to-r from-[#7b898d] via-[#e5eaeb] to-[#717f84] shadow-sm transition-transform"
        style={{ transform: `translate(-50%, -100%) rotate(${high ? 30 : -30}deg)` }}
      />
      <span className={`absolute right-1 top-1 h-1.5 w-1.5 rounded-full ${high ? 'bg-[#35c5cb] shadow-[0_0_6px_rgba(53,197,203,.8)]' : 'bg-[#766d61]'}`} />
    </div>
  );
}

function PhotoGateGraphic({ transparent }: { transparent: boolean }) {
  return (
    <div className="relative mx-auto h-8 w-10">
      <div className="absolute bottom-0 left-0 right-0 h-2 rounded-md border border-[#5d6670] bg-[#253743] shadow-sm" />
      <div className="absolute bottom-1 left-0 h-7 w-3 rounded-t-md border border-[#53636d] bg-gradient-to-r from-[#243946] to-[#4b6471]" />
      <div className="absolute bottom-1 right-0 h-7 w-3 rounded-t-md border border-[#53636d] bg-gradient-to-l from-[#243946] to-[#4b6471]" />
      <div className={`absolute left-2.5 right-2.5 top-3.5 h-[2px] rounded-full transition-all ${transparent ? 'bg-[#65d7c8] shadow-[0_0_7px_rgba(101,215,200,.85)]' : 'bg-[#8d625c]/50'}`} />
      {!transparent && <div className="absolute left-1/2 top-0 h-7 w-1.5 -translate-x-1/2 rounded-sm border border-[#6c665e] bg-[#b1a58f] shadow-sm" />}
    </div>
  );
}

function EncoderGraphic({ clicks }: { clicks: number }) {
  return (
    <div className="relative h-10 w-10 rounded-full border border-[#857a67] bg-[#d3c8b6] p-[3px] shadow-inner">
      <div className="absolute inset-[2px] rounded-full opacity-45" style={{ background: 'repeating-conic-gradient(from -3deg, #7d7468 0 2deg, transparent 2deg 18deg)' }} />
      <div className="device-metal absolute inset-[6px] rounded-full border border-[#79766f] shadow-[0_2px_4px_rgba(31,45,53,.22)]">
        <div className="absolute left-1/2 top-1/2 h-[9px] w-[2px] origin-bottom rounded-full bg-[#158f9a]" style={{ transform: `translate(-50%, -100%) rotate(${clicks * 24}deg)`, transformOrigin: '50% 100%' }} />
        <div className="absolute left-1/2 top-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#8f8a81] bg-[#f4f1e9]" />
      </div>
    </div>
  );
}

function PotGraphic({ value }: { value: number }) {
  const angle = -135 + percent(value) * 2.7;
  return (
    <div className="relative h-10 w-10 rounded-full border border-[#9d8969] bg-[#e0d2ba] shadow-inner">
      <div className="absolute inset-[3px] rounded-full border border-[#776f64] bg-[#263d49] shadow-[inset_0_0_8px_rgba(0,0,0,.35)]" />
      <div className="absolute inset-[7px] rounded-full bg-gradient-to-br from-[#536c78] via-[#b9c4c6] to-[#405660] shadow-md" />
      <div className="absolute left-1/2 top-1/2 h-[13px] w-[2px] origin-bottom rounded-full bg-[#58d4d6]" style={{ transform: `translate(-50%, -100%) rotate(${angle}deg)`, transformOrigin: '50% 100%' }} />
      <div className="absolute left-1/2 top-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#737f83] bg-[#eef1ed]" />
    </div>
  );
}

function ReflectGraphic({ value }: { value: number }) {
  const strength = percent(value);
  return (
    <div className="relative h-9 w-11">
      <div className="absolute left-0 top-1.5 h-6 w-5 rounded-md border border-[#445763] bg-[#233844] shadow-inner">
        <div className="absolute left-1 top-1 h-2 w-2 rounded-full border border-[#8aa1aa] bg-[#dbe4e3]" />
        <div className="absolute bottom-1 right-1 h-2 w-2 rounded-full border border-[#3d786c] bg-[#4cb59c] shadow-[0_0_5px_rgba(76,181,156,.4)]" />
      </div>
      <div className="absolute right-0 top-0.5 h-8 w-1.5 rounded-sm border border-[#9a896f] bg-gradient-to-r from-[#c6b28e] to-[#8d7b61]" />
      <div className="absolute left-5 top-3 h-[2px] origin-left rounded-full bg-[#e5b05d]" style={{ width: 19, opacity: 0.15 + strength / 118 }} />
      <div className="absolute left-5 top-5 h-[2px] origin-left rounded-full bg-[#5ac4d0] shadow-[0_0_4px_rgba(90,196,208,.45)]" style={{ width: 19, opacity: 0.15 + strength / 118 }} />
    </div>
  );
}

function JoystickPad({ x, y, onChange }: { x: number; y: number; onChange: (x: number, y: number) => void }) {
  const padRef = useRef<HTMLDivElement | null>(null);
  const updateFromPointer = (event: ReactPointerEvent<HTMLDivElement>) => {
    const rect = padRef.current?.getBoundingClientRect();
    if (!rect) return;
    const radius = Math.max(1, Math.min(rect.width, rect.height) * 0.32);
    let nx = (event.clientX - (rect.left + rect.width / 2)) / radius;
    let ny = ((rect.top + rect.height / 2) - event.clientY) / radius;
    const length = Math.hypot(nx, ny);
    if (length > 1) {
      nx /= length;
      ny /= length;
    }
    onChange(Math.round(512 + nx * 511), Math.round(512 + ny * 511));
  };
  const release = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    onChange(512, 512);
  };
  const left = 50 + ((x - 512) / 511) * 32;
  const top = 50 - ((y - 512) / 511) * 32;
  return (
    <div ref={padRef} role="application" aria-label="JOYSTICK 2D control" className="relative h-[54px] w-[54px] shrink-0 rounded-xl border border-[#8d7c63] bg-[#cdbd9f] shadow-[inset_0_1px_4px_rgba(78,61,39,.28)]" style={{ touchAction: 'none' }} onPointerDown={event => { event.currentTarget.setPointerCapture(event.pointerId); updateFromPointer(event); }} onPointerMove={event => { if (event.currentTarget.hasPointerCapture(event.pointerId)) updateFromPointer(event); }} onPointerUp={release} onPointerCancel={release}>
      <div className="absolute inset-[5px] rounded-full border border-[#657985] bg-[#203642] shadow-[inset_0_4px_8px_rgba(0,0,0,.35)]" />
      <div className="absolute left-1/2 top-1/2 h-px w-[36px] -translate-x-1/2 bg-[#7b959f]/45" />
      <div className="absolute left-1/2 top-1/2 h-[36px] w-px -translate-y-1/2 bg-[#7b959f]/45" />
      <div className="absolute left-1/2 top-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#6e8790]" />
      <div className="absolute h-[17px] w-[17px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#617079] bg-gradient-to-br from-[#72828a] via-[#2d424d] to-[#172a34] shadow-[0_3px_5px_rgba(0,0,0,.36)]" style={{ left: `${left}%`, top: `${top}%` }}>
        <div className="absolute inset-[4px] rounded-full border border-white/10" />
      </div>
    </div>
  );
}

function DistanceGraphic({ mm, error }: { mm: number; error: boolean }) {
  const normalized = Math.max(0, Math.min(1, (mm - DSEN_UI_MIN_MM) / (DSEN_MAX_MM - DSEN_UI_MIN_MM)));
  return (
    <div className="relative h-8 w-10 shrink-0">
      <div className="absolute left-0 top-1 h-6 w-7 rounded-md border border-[#5e727d] bg-[#2c4755] shadow-sm">
        <div className="device-metal absolute left-0.5 top-1 h-4 w-4 rounded-full border border-[#65757d] shadow-inner" />
        <div className="device-metal absolute right-0.5 top-1 h-4 w-4 rounded-full border border-[#65757d] shadow-inner" />
        <div className="absolute left-[8px] top-[8px] h-1.5 w-1.5 rounded-full bg-[#283b44]" />
        <div className="absolute right-[8px] top-[8px] h-1.5 w-1.5 rounded-full bg-[#283b44]" />
      </div>
      <div className={`absolute left-7 top-[15px] h-[2px] rounded-full ${error ? 'bg-[#d95c57]' : 'bg-[#35c5cb] shadow-[0_0_5px_rgba(53,197,203,.55)]'}`} style={{ width: 10 * normalized }} />
      <div className={`absolute top-1 h-6 w-1 rounded ${error ? 'bg-[#c65f56]' : 'bg-[#b99358]'}`} style={{ left: 28 + 9 * normalized }} />
    </div>
  );
}

function AnalogRow({ label, signal, value, measured, mapping, secondary, graphic, onChange }: { label: string; signal: InputSignal; value: number; measured?: number; mapping: Record<InputSignal, ArduinoTarget>; secondary?: string; graphic: ReactNode; onChange: (value: number) => void }) {
  return <label className="device-card grid min-h-11 min-w-0 grid-cols-[38px_minmax(0,1fr)_42px] items-center gap-1 rounded-lg border border-[#cbdbe5] bg-white/80 px-1 py-1 shadow-[0_2px_7px_rgba(64,91,108,0.04)]"><div className="flex min-w-0 justify-center">{graphic}</div><div className="min-w-0"><div className="flex min-w-0 flex-wrap items-center gap-x-1 gap-y-0 leading-tight"><span className="text-[7px] font-black text-[#405766]">{label}</span><PinBadge signal={signal} mapping={mapping} /></div><input aria-label={`${label} input value`} type="range" min="0" max="1023" value={value} onChange={event => onChange(Number(event.target.value))} className="io-range min-w-0 w-full" /></div><div className="min-w-0 text-right"><div className="mono text-[7px] font-black text-[#2f6f99]">{measured ?? value}</div><div className="text-[6px] font-bold leading-tight text-[#85949e]">{secondary ?? `設定 ${value}`}</div></div></label>;
}

function DistanceRow({ raw, measuredRaw, mapping, onChange }: { raw: number; measuredRaw: number; mapping: Record<InputSignal, ArduinoTarget>; onChange: (raw: number) => void }) {
  const mm = dsenRawToMm(raw);
  const error = mm < DSEN_MIN_VALID_MM;
  return <label className={`device-card grid min-h-[54px] min-w-0 grid-cols-[36px_minmax(0,1fr)_42px] items-center gap-1 rounded-lg border px-1 py-1 shadow-[0_2px_7px_rgba(64,91,108,0.04)] ${error ? 'is-error border-[#d99b91] bg-[#fff1ee]' : 'border-[#cbdbe5] bg-white/80'}`}><div className="flex min-w-0 justify-center"><DistanceGraphic mm={mm} error={error} /></div><div className="min-w-0"><div className="flex min-w-0 flex-wrap items-center gap-x-1 gap-y-0 leading-tight"><span className="text-[7px] font-black text-[#405766]">DSEN</span><PinBadge signal="DSEN" mapping={mapping} /></div><input aria-label="DSEN distance mm" type="range" min={DSEN_UI_MIN_MM} max={DSEN_MAX_MM} value={mm} onChange={event => onChange(dsenMmToRaw(Number(event.target.value)))} className="io-range min-w-0 w-full" /><div className="grid min-w-0 grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-0.5 text-[6px] font-bold leading-tight text-[#85949e]"><span>2cm</span><span className={`min-w-0 text-center ${error ? 'text-[#ad5b50]' : ''}`}>{error ? '3cm未満 ERROR' : '有効 3〜20cm'}</span><span>20cm</span></div></div><div className="min-w-0 text-right"><div className={`mono text-[7px] font-black ${error ? 'text-[#b55248]' : 'text-[#2f6f99]'}`}>{error ? 'ERROR' : `${mm}mm`}</div><div className="text-[6px] font-bold leading-tight text-[#85949e]">ADC<br />{measuredRaw}</div></div></label>;
}

type Props = {
  deviceState: DeviceState;
  measured: MeasuredInputs;
  mapping: Record<InputSignal, ArduinoTarget>;
  polarity: InputPolarity;
  joystickDirection: JoystickDirection;
  polarityChanged: boolean;
  encoderClicks: number;
  encoderBusy: boolean;
  encoderAHigh: boolean;
  encoderBHigh: boolean;
  mappingChanged: boolean;
  onDeviceStateChange: (patch: Partial<DeviceState>) => void;
  onRotateEncoder: (direction: -1 | 1) => void;
  onResetInputs: () => void;
  onResetMapping: () => void;
  onMappingChange: (signal: InputSignal, target: ArduinoTarget) => void;
  onResetPolarity: () => void;
  onPolarityChange: (signal: ActivePolaritySignal, polarity: ActivePolarity) => void;
  onJoystickDirectionChange: (axis: 'X' | 'Y', direction: JoystickDirection['X'] | JoystickDirection['Y']) => void;
};

function WorkbenchMonitor({ deviceState, measured, mapping, polarity, joystickDirection, polarityChanged, encoderClicks, encoderBusy, encoderAHigh, encoderBHigh, mappingChanged, onDeviceStateChange, onRotateEncoder, onResetInputs, onResetMapping, onMappingChange, onResetPolarity, onPolarityChange, onJoystickDirectionChange }: Props) {
  const [mappingOpen, setMappingOpen] = useState(false);
  const [polarityOpen, setPolarityOpen] = useState(false);

  useEffect(() => {
    const closeSettings = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      setMappingOpen(false);
      setPolarityOpen(false);
    };
    window.addEventListener('keydown', closeSettings);
    return () => window.removeEventListener('keydown', closeSettings);
  }, []);

  return <>
    <section className="io-panel input-panel flex h-full min-h-0 flex-col overflow-y-auto rounded-xl border border-[#b9d0df] bg-[#eef6fa] p-1.5 shadow-[0_8px_22px_rgba(69,101,122,0.06)] sm:p-2">
      <div className="grid min-h-7 shrink-0 grid-cols-[minmax(0,1fr)_auto] items-center gap-1"><div className="min-w-0"><div className="text-[8px] font-black tracking-[0.08em] text-[#32698e]">INPUT DEVICES</div><div className="hidden text-[6px] font-bold leading-tight text-[#7f929e] min-[700px]:block">実機ばらつき・チャタリングを含む信号状態</div></div><div className="flex shrink-0 gap-0.5"><button type="button" onClick={() => setMappingOpen(true)} className={`min-h-8 rounded-md border px-1 text-[7px] font-black ${mappingChanged ? 'border-[#d9bd82] bg-[#f6ead3] text-[#8b692f]' : 'border-[#a9c8da] bg-white/65 text-[#3c759b]'}`}><Cable size={9} className="inline" /><span className="hidden min-[700px]:inline"> 配線</span></button><button type="button" onClick={() => setPolarityOpen(true)} className={`min-h-8 rounded-md border px-1 text-[7px] font-black ${polarityChanged ? 'border-[#c6aad9] bg-[#efe4f6] text-[#6e4d84]' : 'border-[#cbd8e1] bg-white/65 text-[#617886]'}`}>極性</button><button type="button" onClick={onResetInputs} className="min-h-7 rounded-md border border-[#cbd8e1] bg-white/65 px-1 text-[6px] font-black text-[#617886]"><RotateCcw size={9} className="inline" /><span className="hidden min-[700px]:inline"> RESET</span></button></div></div>
      <div className="device-digital-strip grid shrink-0 grid-cols-3 gap-1">
        <button type="button" aria-pressed={deviceState.tcPressed} aria-label={`TC ${deviceState.tcPressed ? '押下' : '待機'}・入力${measured.tcHigh ? 'HIGH' : 'LOW'}`} onPointerDown={() => onDeviceStateChange({ tcPressed: true })} onPointerUp={() => onDeviceStateChange({ tcPressed: false })} onPointerCancel={() => onDeviceStateChange({ tcPressed: false })} onPointerLeave={() => onDeviceStateChange({ tcPressed: false })} onKeyDown={event => { if (event.key === ' ' || event.key === 'Enter') { event.preventDefault(); onDeviceStateChange({ tcPressed: true }); } }} onKeyUp={event => { if (event.key === ' ' || event.key === 'Enter') { event.preventDefault(); onDeviceStateChange({ tcPressed: false }); } }} className={`device-card rounded-lg border px-1 py-1 ${deviceState.tcPressed ? 'is-active border-[#6e9fc0] bg-[#dcebf5]' : 'border-[#ccdbe4] bg-white/80'}`}><TactileGraphic pressed={deviceState.tcPressed} /><div className="mt-0.5 flex items-center justify-center gap-1"><span className="text-[8px] font-black">TC<span className="device-physical-state">{deviceState.tcPressed ? '押下' : '待機'}</span></span><LogicBadge high={measured.tcHigh} /></div><PinBadge signal="TC" mapping={mapping} /></button>
        <button type="button" aria-pressed={deviceState.tgHigh} aria-label={`TG ${deviceState.tgHigh ? 'ON' : 'OFF'}・入力${measured.tgHigh ? 'HIGH' : 'LOW'}`} onClick={() => onDeviceStateChange({ tgHigh: !deviceState.tgHigh })} className={`device-card rounded-lg border px-1 py-1 ${deviceState.tgHigh ? 'is-active border-[#8cb8a7] bg-[#e0efe9]' : 'border-[#ccdbe4] bg-white/80'}`}><ToggleGraphic high={deviceState.tgHigh} /><div className="mt-0.5 flex items-center justify-center gap-1"><span className="text-[8px] font-black">TG<span className="device-physical-state">{deviceState.tgHigh ? 'ON' : 'OFF'}</span></span><LogicBadge high={measured.tgHigh} /></div><PinBadge signal="TG" mapping={mapping} /></button>
        <button type="button" aria-pressed={deviceState.phTransparent} aria-label={`PH ${deviceState.phTransparent ? '透過' : '遮断'}・入力${measured.phHigh ? 'HIGH' : 'LOW'}`} onClick={() => onDeviceStateChange({ phTransparent: !deviceState.phTransparent })} className={`device-card rounded-lg border px-1 py-1 ${deviceState.phTransparent ? 'is-active border-[#adabd0] bg-[#eeedf8]' : 'border-[#ccdbe4] bg-white/80'}`}><PhotoGateGraphic transparent={deviceState.phTransparent} /><div className="mt-0.5 flex items-center justify-center gap-1"><span className="text-[8px] font-black">PH<span className="device-physical-state">{deviceState.phTransparent ? '透過' : '遮断'}</span></span><LogicBadge high={measured.phHigh} /></div><PinBadge signal="PH" mapping={mapping} /></button>
      </div>
      <div className="device-card mt-1 grid min-w-0 shrink-0 grid-cols-[42px_minmax(0,1fr)] gap-1 rounded-lg border border-[#b5cfdf] bg-[#e8f3f8] p-1"><div className="flex min-w-0 items-center justify-center"><EncoderGraphic clicks={encoderClicks} /></div><div className="min-w-0"><div className="flex min-w-0 flex-wrap items-center justify-between gap-x-1 gap-y-0"><div className="min-w-0"><div className="text-[7px] font-black leading-tight text-[#32698e]">ROTARY ENC <span className="mono">{encoderClicks > 0 ? `+${encoderClicks}` : encoderClicks}</span></div><div className="flex flex-wrap gap-x-1"><PinBadge signal="ENCA" mapping={mapping} /><PinBadge signal="ENCB" mapping={mapping} /></div></div><div className="flex shrink-0 gap-0.5"><LogicBadge high={encoderAHigh} /><LogicBadge high={encoderBHigh} /></div></div><div className="mt-1 grid grid-cols-2 gap-1"><button type="button" disabled={encoderBusy} onClick={() => onRotateEncoder(-1)} className="min-h-8 rounded-md border border-[#cbd8e1] bg-white/80 text-[7px] font-black disabled:opacity-40">↶ CCW</button><button type="button" disabled={encoderBusy} onClick={() => onRotateEncoder(1)} className="min-h-8 rounded-md border border-[#9ebfd4] bg-[#dcebf5] text-[7px] font-black text-[#2f668d] disabled:opacity-40">CW ↷</button></div></div></div>
      <div className="mt-1 grid min-h-0 flex-1 content-start gap-1">
        <AnalogRow label="PR 反射量" signal="PR" value={deviceState.prRaw} measured={measured.prRaw} mapping={mapping} secondary={deviceState.prRaw < 40 ? `透過 · ACT ${polarity.PR}` : `反射 ${percent(deviceState.prRaw)}% · ACT ${polarity.PR}`} graphic={<ReflectGraphic value={deviceState.prRaw} />} onChange={value => onDeviceStateChange({ prRaw: value })} />
        <AnalogRow label="VR 可変抵抗" signal="VR" value={deviceState.vrRaw} measured={measured.vrRaw} mapping={mapping} secondary={`設定 ${deviceState.vrRaw}`} graphic={<PotGraphic value={deviceState.vrRaw} />} onChange={value => onDeviceStateChange({ vrRaw: value })} />
        <div className="device-card min-w-0 rounded-lg border border-[#cbdbe5] bg-white/80 px-1 py-1 shadow-[0_2px_7px_rgba(64,91,108,0.04)]"><div className="flex min-w-0 items-center gap-1.5"><div className="w-[58px] shrink-0"><div className="flex justify-center"><JoystickPad x={deviceState.joyX} y={deviceState.joyY} onChange={(joyX, joyY) => onDeviceStateChange({ joyX, joyY })} /></div><div className="mt-0.5 text-center text-[6px] font-black leading-tight text-[#80919c]">{joystickDirection.Y === 'UP_MAX' ? '↑Y MAX' : 'Y MAX↓'}<br />{joystickDirection.X === 'RIGHT_MAX' ? 'X MAX→' : '←X MAX'}</div></div><div className="min-w-0 flex-1"><div className="flex min-w-0 flex-wrap items-center gap-x-1 gap-y-0 text-[7px] font-black leading-tight text-[#405766]">JOYSTICK <PinBadge signal="JOYX" mapping={mapping} /><PinBadge signal="JOYY" mapping={mapping} /></div><div className="mt-1 grid min-w-0 grid-cols-2 gap-1"><div className="rounded bg-[#eef5f9] px-1 py-0.5 text-center"><div className="text-[6px] font-bold text-[#80919c]">X</div><div className="mono text-[7px] font-black text-[#2f6f99]">{measured.joyX}</div></div><div className="rounded bg-[#eef5f9] px-1 py-0.5 text-center"><div className="text-[6px] font-bold text-[#80919c]">Y</div><div className="mono text-[7px] font-black text-[#2f6f99]">{measured.joyY}</div></div></div><div className="mt-1 text-[6px] font-bold leading-tight text-[#7b8d98]">ドラッグ操作 · 離すと中央復帰</div></div></div></div>
        <DistanceRow raw={deviceState.dsenRaw} measuredRaw={measured.dsenRaw} mapping={mapping} onChange={value => onDeviceStateChange({ dsenRaw: value })} />
      </div>
    </section>

    {polarityOpen && <div className="modal-backdrop fixed inset-0 z-[125] overflow-y-auto bg-[#dce6ec]/80 p-2 backdrop-blur sm:p-6"><div role="dialog" aria-modal="true" className="modal-card mx-auto max-h-[calc(100dvh-1rem)] max-w-md overflow-y-auto rounded-2xl border border-[#d8cdbc] bg-[#fffaf2] p-3 text-[#354957] shadow-[0_22px_55px_rgba(60,77,91,0.18)] sm:max-h-[calc(100dvh-3rem)] sm:p-4"><div className="flex items-start justify-between gap-3"><div><h2 className="font-black">入力器具の極性・方向</h2><p className="mt-1 text-[11px] leading-5 text-[#778590]">デジタル/PRはACTIVE極性、JOYはADC=1023になる物理方向を切り替えます。</p></div><button type="button" onClick={() => setPolarityOpen(false)} className="min-h-11 min-w-11 rounded-lg border border-[#d6d0c7] bg-white" aria-label="極性設定を閉じる"><X size={18} className="mx-auto" /></button></div><div className="mt-3 grid gap-1.5">{polaritySignals.map(signal => <div key={signal} className="grid grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-1.5 rounded-xl border border-[#ded7cd] bg-white/70 p-2"><div><div className="text-[11px] font-black">{polarityNames[signal]}</div><div className="text-[8px] font-semibold text-[#8a9297]">現在 ACTIVE {polarity[signal]}</div></div><button type="button" onClick={() => onPolarityChange(signal, 'HIGH')} className={`min-h-9 rounded-lg border px-2 text-[9px] font-black ${polarity[signal] === 'HIGH' ? 'border-[#7fa8c2] bg-[#dcebf5] text-[#356f94]' : 'border-[#d4dce0] bg-white text-[#71818d]'}`}>HIGH</button><button type="button" onClick={() => onPolarityChange(signal, 'LOW')} className={`min-h-9 rounded-lg border px-2 text-[9px] font-black ${polarity[signal] === 'LOW' ? 'border-[#b79bc8] bg-[#eee3f4] text-[#6b4d7c]' : 'border-[#d4dce0] bg-white text-[#71818d]'}`}>LOW</button></div>)}<div className="grid grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-1.5 rounded-xl border border-[#cbdbe5] bg-[#f7fbfd] p-2"><div><div className="text-[11px] font-black">JOY X 最大値方向</div><div className="text-[8px] font-semibold text-[#8a9297]">ADC 1023 = {joystickDirection.X === 'RIGHT_MAX' ? '右' : '左'}</div></div><button type="button" onClick={() => onJoystickDirectionChange('X', 'RIGHT_MAX')} className={`min-h-9 rounded-lg border px-2 text-[9px] font-black ${joystickDirection.X === 'RIGHT_MAX' ? 'border-[#7fa8c2] bg-[#dcebf5] text-[#356f94]' : 'border-[#d4dce0] bg-white text-[#71818d]'}`}>右MAX</button><button type="button" onClick={() => onJoystickDirectionChange('X', 'LEFT_MAX')} className={`min-h-9 rounded-lg border px-2 text-[9px] font-black ${joystickDirection.X === 'LEFT_MAX' ? 'border-[#7fa8c2] bg-[#dcebf5] text-[#356f94]' : 'border-[#d4dce0] bg-white text-[#71818d]'}`}>左MAX</button></div><div className="grid grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-1.5 rounded-xl border border-[#cbdbe5] bg-[#f7fbfd] p-2"><div><div className="text-[11px] font-black">JOY Y 最大値方向</div><div className="text-[8px] font-semibold text-[#8a9297]">ADC 1023 = {joystickDirection.Y === 'UP_MAX' ? '上' : '下'}</div></div><button type="button" onClick={() => onJoystickDirectionChange('Y', 'UP_MAX')} className={`min-h-9 rounded-lg border px-2 text-[9px] font-black ${joystickDirection.Y === 'UP_MAX' ? 'border-[#7fa8c2] bg-[#dcebf5] text-[#356f94]' : 'border-[#d4dce0] bg-white text-[#71818d]'}`}>上MAX</button><button type="button" onClick={() => onJoystickDirectionChange('Y', 'DOWN_MAX')} className={`min-h-9 rounded-lg border px-2 text-[9px] font-black ${joystickDirection.Y === 'DOWN_MAX' ? 'border-[#7fa8c2] bg-[#dcebf5] text-[#356f94]' : 'border-[#d4dce0] bg-white text-[#71818d]'}`}>下MAX</button></div></div><div className="mt-3 rounded-xl bg-[#eef5f9] p-2 text-[9px] leading-4 text-[#667985]">PRは「反射した時にADCが上がる=HIGH / 下がる=LOW」。JOYはスティックの物理方向は変えず、X/YそれぞれのADC増加方向だけ反転します。</div><button type="button" onClick={onResetPolarity} className="mt-3 min-h-10 w-full rounded-xl border border-[#d6d0c7] bg-white text-[10px] font-black text-[#657580]">標準極性・方向へ戻す</button></div></div>}

    {mappingOpen && <div className="modal-backdrop fixed inset-0 z-[120] overflow-y-auto bg-[#dce6ec]/80 p-2 backdrop-blur sm:p-6"><div role="dialog" aria-modal="true" className="modal-card mx-auto max-h-[calc(100dvh-1rem)] max-w-2xl overflow-y-auto rounded-2xl border border-[#d8cdbc] bg-[#fffaf2] p-3 text-[#354957] shadow-[0_22px_55px_rgba(60,77,91,0.18)] sm:max-h-[calc(100dvh-3rem)] sm:p-4"><div className="sticky top-0 z-10 -mx-1 flex items-start justify-between gap-3 bg-[#fffaf2]/95 px-1 pb-3 backdrop-blur"><div><h2 className="font-black">15ピン入力コネクタ → Arduino</h2><p className="mt-1 text-[11px] leading-5 text-[#778590]">入力器具側は固定。Arduino側の接続先だけ変更します。</p></div><button type="button" onClick={() => setMappingOpen(false)} className="min-h-11 min-w-11 rounded-lg border border-[#d6d0c7] bg-white" aria-label="配線設定を閉じる"><X size={18} className="mx-auto" /></button></div>{mappingChanged && <div className="mb-3 flex items-center justify-between gap-2 rounded-xl border border-[#dfc58d] bg-[#f6ead3] p-2.5 text-[11px] font-semibold text-[#7f622f]"><span>標準配線から変更されています。</span><button type="button" onClick={onResetMapping} className="min-h-9 rounded-lg border border-[#d2b878] bg-white/65 px-2 font-black">標準へ戻す</button></div>}<div className="grid grid-cols-[42px_minmax(0,1fr)_96px] gap-1.5 text-xs sm:grid-cols-[48px_minmax(0,1fr)_minmax(110px,150px)]"><div className="px-1 text-[#87939b]">PIN</div><div className="px-1 text-[#87939b]">入力</div><div className="px-1 text-[#87939b]">Arduino</div><div className="rounded-lg bg-[#f5efe5] p-2">P1</div><div className="rounded-lg bg-[#f5efe5] p-2 font-bold">+5V</div><div className="rounded-lg bg-[#eef6f1] p-2 font-bold text-[#477865]">5V</div><div className="rounded-lg bg-[#f5efe5] p-2">P2</div><div className="rounded-lg bg-[#f5efe5] p-2 font-bold">GND</div><div className="rounded-lg bg-[#eef5f9] p-2 font-bold text-[#3d7398]">GND</div>{([...digitalSignals, ...analogSignals] as InputSignal[]).sort((a, b) => connectorPins[a] - connectorPins[b]).map(signal => { const options = digitalSignals.includes(signal) ? digitalArduinoTargets : analogArduinoTargets; return <div key={signal} className="contents"><div className="rounded-lg bg-[#f5efe5] p-2">P{connectorPins[signal]}</div><div className="rounded-lg bg-[#f5efe5] p-2 font-bold">{labels[signal]}</div><select aria-label={`${labels[signal]} Arduino mapping`} value={mapping[signal]} onChange={event => onMappingChange(signal, event.target.value as ArduinoTarget)} className="min-h-11 min-w-0 rounded-lg border border-[#cbd8e1] bg-white px-2 text-base text-[#354957] sm:text-xs">{options.map(target => <option key={target} value={target}>{target}</option>)}</select></div>; })}{[13, 14, 15].map(pin => <div key={pin} className="contents"><div className="rounded-lg bg-[#f5efe5] p-2">P{pin}</div><div className="rounded-lg bg-[#f5efe5] p-2 text-[#87939b]">予備</div><div className="rounded-lg bg-[#f5efe5] p-2 text-[#9aa4aa]">NC</div></div>)}</div><p className="mt-3 text-[11px] leading-5 text-[#7d8992]">標準: TC→D1 / TG→D3 / PH→D5 / PR→A2 / VR→A4 / JOY X→A6 / JOY Y→A8 / ENC A/B→D20/D21 / DSEN→A10。</p></div></div>}
  </>;
}

export default WorkbenchMonitor;
