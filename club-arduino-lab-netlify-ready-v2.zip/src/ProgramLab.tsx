import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AlignLeft, Code2, FileDown, FileUp, MoreHorizontal, Play, RotateCcw, Save, SlidersHorizontal, Square, Trash2, Volume2, VolumeX, X } from 'lucide-react';
import AvrWorkbench, { type WorkbenchStatus } from './AvrWorkbench';
import CppEditor, { formatCpp } from './CppEditor';
import LiveOutputPanel from './LiveOutputPanel';
import WorkbenchMonitor, {
  analogArduinoTargets,
  defaultDeviceState,
  defaultInputMapping,
  defaultInputPolarity,
  defaultJoystickDirection,
  digitalArduinoTargets,
  dsenRawToMm,
  DSEN_MIN_VALID_MM,
  type ActivePolarity,
  type ActivePolaritySignal,
  type DeviceState,
  type InputPolarity,
  type InputSignal,
  type JoystickDirection,
  type MeasuredInputs,
} from './WorkbenchMonitor';
import { readInputRealismSeed, sampleRealisticInputVoltages } from './inputRealism';
import { useSpeakerAudio } from './useSpeakerAudio';
import type { ArduinoTarget } from './sim';
import type { MegaSnapshot } from './avrMega';

const sampleSource = `#include <Arduino.h>

void dcm(int speed, int muki){
  analogWrite(11, muki > 0 ? 255 : speed);
  analogWrite(12, muki < 0 ? 255 : speed);
}

int stpm(int speed, int muki){
  static int i;
  static unsigned long time;
  if(millis() - time > (unsigned long)speed){
    i = (i + muki + 4) % 4;
    PORTA = 1 << i;
    time = millis();
    return 1;
  }
  return 0;
}

void cled_light(int r, int g, int b){
  analogWrite(44, r);
  analogWrite(45, g);
  analogWrite(46, b);
}

void seg_light(byte l, byte m, byte r){
  digitalWrite(49, LOW);
  shiftOut(48, 47, MSBFIRST, l);
  shiftOut(48, 47, MSBFIRST, m);
  shiftOut(48, 47, MSBFIRST, r);
  digitalWrite(49, HIGH);
}

void setup(){
  Serial.begin(115200);
  DDRA = DDRB = DDRL = 0xff;
}

void loop(){
  dcm(180, 1);
  stpm(12, 1);
  cled_light(80, 30, 180);
  seg_light(0x3F, 0x06, 0x5B);
  tone(43, 880);
}`;

function readDeviceState(): DeviceState {
  try {
    const saved = JSON.parse(localStorage.getItem('club-program-device-state') || '{}') as Partial<DeviceState>;
    const merged = { ...defaultDeviceState, ...saved };
    if (localStorage.getItem('club-pr-physical-v1') !== '1') {
      merged.prRaw = defaultDeviceState.prRaw;
      localStorage.setItem('club-pr-physical-v1', '1');
    }
    return merged;
  } catch {
    return { ...defaultDeviceState };
  }
}

function readInputMapping(): Record<InputSignal, ArduinoTarget> {
  try {
    const saved = JSON.parse(localStorage.getItem('club-program-input-mapping') || '{}') as Partial<Record<InputSignal, ArduinoTarget>>;
    return { ...defaultInputMapping, ...saved };
  } catch {
    return { ...defaultInputMapping };
  }
}

function readInputPolarity(): InputPolarity {
  try {
    const saved = JSON.parse(localStorage.getItem('club-program-input-polarity') || '{}') as Partial<InputPolarity>;
    return { ...defaultInputPolarity, ...saved };
  } catch {
    return { ...defaultInputPolarity };
  }
}

function readJoystickDirection(): JoystickDirection {
  try {
    const saved = JSON.parse(localStorage.getItem('club-program-joystick-direction') || '{}') as Partial<JoystickDirection>;
    return { ...defaultJoystickDirection, ...saved };
  } catch {
    return { ...defaultJoystickDirection };
  }
}

type ProgramSave = { name: string; source: string; savedAt: number };
type SourceBackup = { name: string; source: string; savedAt: number; reason: string };
const PROGRAM_SAVES_KEY = 'club-program-saves-v1';
const SOURCE_BACKUP_KEY = 'club-arduino-source-backup-v1';

function readSourceBackup(): SourceBackup | null {
  try {
    const saved = JSON.parse(localStorage.getItem(SOURCE_BACKUP_KEY) || 'null') as SourceBackup | null;
    return saved && typeof saved.name === 'string' && typeof saved.source === 'string' ? saved : null;
  } catch {
    return null;
  }
}

function normalizeProgramName(value: string) {
  const trimmed = value.trim() || 'practice.cpp';
  return trimmed.toLowerCase().endsWith('.cpp') ? trimmed : `${trimmed}.cpp`;
}

function readProgramSaves(): ProgramSave[] {
  try {
    const saved = JSON.parse(localStorage.getItem(PROGRAM_SAVES_KEY) || '[]') as ProgramSave[];
    return Array.isArray(saved) ? saved.filter(item => item && typeof item.name === 'string' && typeof item.source === 'string').sort((a, b) => b.savedAt - a.savedAt) : [];
  } catch {
    return [];
  }
}

const readView = () => (localStorage.getItem('club-main-view') === 'io' ? 'io' as const : 'program' as const);
const rawFromVoltage = (voltage: number | null | undefined) => Math.max(0, Math.min(1023, Math.round(((voltage ?? 0) / 5) * 1023)));

type BouncyKey = 'tcPressed' | 'tgHigh' | 'phTransparent';

function ProgramLab() {
  const [view, setView] = useState<'program' | 'io'>(readView);
  const [source, setSource] = useState(() => localStorage.getItem('club-arduino-source') || sampleSource);
  const [sourceFileName, setSourceFileName] = useState(() => localStorage.getItem('club-arduino-source-name') || 'practice.cpp');
  const [deviceState, setDeviceState] = useState<DeviceState>(readDeviceState);
  const [electricalDigital, setElectricalDigital] = useState(() => ({ tcPressed: deviceState.tcPressed, tgHigh: deviceState.tgHigh, phTransparent: deviceState.phTransparent }));
  const [noiseTick, setNoiseTick] = useState(0);
  const bounceTimersRef = useRef<Partial<Record<BouncyKey, number[]>>>({});
  const realismSeedRef = useRef(readInputRealismSeed());
  const [inputMapping, setInputMapping] = useState<Record<InputSignal, ArduinoTarget>>(readInputMapping);
  const [inputPolarity, setInputPolarity] = useState<InputPolarity>(readInputPolarity);
  const [joystickDirection, setJoystickDirection] = useState<JoystickDirection>(readJoystickDirection);
  const [liveMega, setLiveMega] = useState<MegaSnapshot | null>(null);
  const latestMegaRef = useRef<MegaSnapshot | null>(null);
  const viewRef = useRef<'program' | 'io'>(view);
  const speakerHzRef = useRef(0);
  const [speakerHz, setSpeakerHz] = useState(0);
  const dcmRpsRef = useRef(0);
  const [dcmRps, setDcmRps] = useState(0);
  const [encoderPhase, setEncoderPhase] = useState(0);
  const [encoderClicks, setEncoderClicks] = useState(0);
  const [encoderBusy, setEncoderBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [fileMenuOpen, setFileMenuOpen] = useState(false);
  const [programSaves, setProgramSaves] = useState<ProgramSave[]>(readProgramSaves);
  const [sourceBackup, setSourceBackup] = useState<SourceBackup | null>(readSourceBackup);
  const [saveManagerOpen, setSaveManagerOpen] = useState(false);
  const [saveName, setSaveName] = useState(() => localStorage.getItem('club-arduino-source-name') || 'practice.cpp');
  const [buildRequest, setBuildRequest] = useState(0);
  const [stopRequest, setStopRequest] = useState(0);
  const [runStatus, setRunStatus] = useState<WorkbenchStatus>('idle');
  const [builtSource, setBuiltSource] = useState<string | null>(null);
  const [attentionToken, setAttentionToken] = useState(0);
  const [attentionBaseline, setAttentionBaseline] = useState<MegaSnapshot | null>(null);
  const [serialMonitor, setSerialMonitor] = useState('');
  const [serialExpanded, setSerialExpanded] = useState(false);
  const [audioMixerOpen, setAudioMixerOpen] = useState(false);
  const serialPreRef = useRef<HTMLPreElement | null>(null);

  const speaker = useSpeakerAudio(speakerHz, dcmRps);

  useEffect(() => { localStorage.setItem('club-main-view', view); }, [view]);
  useEffect(() => { localStorage.setItem('club-arduino-source', source); }, [source]);
  useEffect(() => { localStorage.setItem('club-arduino-source-name', sourceFileName); }, [sourceFileName]);
  useEffect(() => { localStorage.setItem('club-program-device-state', JSON.stringify(deviceState)); }, [deviceState]);
  useEffect(() => { localStorage.setItem('club-program-input-mapping', JSON.stringify(inputMapping)); }, [inputMapping]);
  useEffect(() => { localStorage.setItem('club-program-input-polarity', JSON.stringify(inputPolarity)); }, [inputPolarity]);
  useEffect(() => { localStorage.setItem('club-program-joystick-direction', JSON.stringify(joystickDirection)); }, [joystickDirection]);
  useEffect(() => { localStorage.setItem(PROGRAM_SAVES_KEY, JSON.stringify(programSaves)); }, [programSaves]);
  useEffect(() => {
    if (!notice) return;
    const id = window.setTimeout(() => setNotice(''), 3200);
    return () => window.clearTimeout(id);
  }, [notice]);
  useEffect(() => {
    const closeTransientUi = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      setFileMenuOpen(false);
      setSaveManagerOpen(false);
      setAudioMixerOpen(false);
      setSerialExpanded(false);
    };
    window.addEventListener('keydown', closeTransientUi);
    return () => window.removeEventListener('keydown', closeTransientUi);
  }, []);
  useEffect(() => {
    if (view !== 'io' && runStatus !== 'running') return;
    const id = window.setInterval(() => setNoiseTick(value => (value + 1) % 1000000), 60);
    return () => window.clearInterval(id);
  }, [runStatus, view]);
  useEffect(() => () => {
    Object.values(bounceTimersRef.current).forEach(timers => timers?.forEach(id => window.clearTimeout(id)));
  }, []);
  useEffect(() => {
    if (view !== 'io' || !serialExpanded || !serialPreRef.current) return;
    serialPreRef.current.scrollTop = serialPreRef.current.scrollHeight;
  }, [serialExpanded, serialMonitor, view]);

  const handleMegaSnapshot = useCallback((next: MegaSnapshot | null) => {
    latestMegaRef.current = next;
    if (!next) {
      setLiveMega(null);
      speakerHzRef.current = 0;
      setSpeakerHz(0);
      dcmRpsRef.current = 0;
      setDcmRps(0);
      return;
    }
    const nextHz = Math.round(next.buzzerHz);
    if (nextHz !== speakerHzRef.current) {
      speakerHzRef.current = nextHz;
      setSpeakerHz(nextHz);
    }
    const nextDcmRps = Math.round(Math.abs(next.dcmRps) * 100) / 100;
    if (Math.abs(nextDcmRps - dcmRpsRef.current) >= 0.01) {
      dcmRpsRef.current = nextDcmRps;
      setDcmRps(nextDcmRps);
    }
    if (viewRef.current === 'io') setLiveMega(next);
  }, []);

  const changeView = useCallback((next: 'program' | 'io') => {
    viewRef.current = next;
    setView(next);
    if (next === 'io') setLiveMega(latestMegaRef.current);
  }, []);

  const encoderState = [0, 2, 3, 1][encoderPhase];
  const sourceDirty = builtSource !== null && source !== builtSource;
  const mappingChanged = useMemo(() => (Object.keys(defaultInputMapping) as InputSignal[]).some(signal => defaultInputMapping[signal] !== inputMapping[signal]), [inputMapping]);
  const polarityChanged = useMemo(() => (Object.keys(defaultInputPolarity) as ActivePolaritySignal[]).some(signal => defaultInputPolarity[signal] !== inputPolarity[signal]) || joystickDirection.X !== defaultJoystickDirection.X || joystickDirection.Y !== defaultJoystickDirection.Y, [inputPolarity, joystickDirection]);

  const sampleInputVoltages = useCallback(() => sampleRealisticInputVoltages({
    state: {
      tcPressed: electricalDigital.tcPressed,
      tgHigh: electricalDigital.tgHigh,
      phTransparent: electricalDigital.phTransparent,
      prRaw: deviceState.prRaw,
      vrRaw: deviceState.vrRaw,
      joyX: deviceState.joyX,
      joyY: deviceState.joyY,
      dsenMm: dsenRawToMm(deviceState.dsenRaw),
    },
    mapping: inputMapping,
    polarity: inputPolarity,
    joystickDirection,
    encoderState,
    chatter: {},
    seed: realismSeedRef.current,
    now: performance.now(),
  }), [deviceState, electricalDigital, encoderState, inputMapping, inputPolarity, joystickDirection]);

  const inputVoltages = useMemo(() => sampleInputVoltages(), [noiseTick, sampleInputVoltages]);

  const measuredInputs = useMemo<MeasuredInputs>(() => {
    const readRaw = (signal: InputSignal) => rawFromVoltage(inputVoltages[inputMapping[signal]]);
    const readHigh = (signal: InputSignal) => (inputVoltages[inputMapping[signal]] ?? 0) >= 3;
    return {
      tcHigh: readHigh('TC'),
      tgHigh: readHigh('TG'),
      phHigh: readHigh('PH'),
      prRaw: readRaw('PR'),
      vrRaw: readRaw('VR'),
      joyX: readRaw('JOYX'),
      joyY: readRaw('JOYY'),
      dsenRaw: readRaw('DSEN'),
      dsenError: dsenRawToMm(deviceState.dsenRaw) < DSEN_MIN_VALID_MM,
    };
  }, [deviceState.dsenRaw, inputMapping, inputVoltages]);

  const markInteraction = () => {
    setAttentionBaseline(liveMega);
    setAttentionToken(value => value + 1);
  };

  const scheduleBounce = (key: BouncyKey, finalValue: boolean) => {
    bounceTimersRef.current[key]?.forEach(id => window.clearTimeout(id));
    setElectricalDigital(current => ({ ...current, [key]: finalValue }));
    const timings = key === 'phTransparent' ? [1, 3] : key === 'tgHigh' ? [3, 6, 10, 14] : [2, 4, 7, 11];
    bounceTimersRef.current[key] = timings.map((delay, index) => window.setTimeout(() => {
      setElectricalDigital(current => ({ ...current, [key]: index % 2 === 0 ? !finalValue : finalValue }));
    }, delay));
  };

  const handleDeviceStateChange = (patch: Partial<DeviceState>) => {
    markInteraction();
    if (patch.tcPressed !== undefined) scheduleBounce('tcPressed', patch.tcPressed);
    if (patch.tgHigh !== undefined) scheduleBounce('tgHigh', patch.tgHigh);
    if (patch.phTransparent !== undefined) scheduleBounce('phTransparent', patch.phTransparent);
    setDeviceState(current => ({ ...current, ...patch }));
  };

  const rotateEncoder = (direction: -1 | 1) => {
    if (encoderBusy) return;
    markInteraction();
    setEncoderBusy(true);
    const start = encoderPhase;
    for (let step = 1; step <= 4; step += 1) {
      const phase = (start + direction * step + 40) % 4;
      const previous = (start + direction * (step - 1) + 40) % 4;
      const baseDelay = step * 16;
      window.setTimeout(() => setEncoderPhase(phase), baseDelay);
      if (step === 1 || step === 3) {
        window.setTimeout(() => setEncoderPhase(previous), baseDelay + 2);
        window.setTimeout(() => setEncoderPhase(phase), baseDelay + 4);
      }
      if (step === 4) window.setTimeout(() => {
        setEncoderClicks(value => value + direction);
        setEncoderBusy(false);
      }, baseDelay + 5);
    }
  };

  const resetInputs = () => {
    markInteraction();
    Object.values(bounceTimersRef.current).forEach(timers => timers?.forEach(id => window.clearTimeout(id)));
    bounceTimersRef.current = {};
    setDeviceState({ ...defaultDeviceState });
    setElectricalDigital({ tcPressed: defaultDeviceState.tcPressed, tgHigh: defaultDeviceState.tgHigh, phTransparent: defaultDeviceState.phTransparent });
    setEncoderPhase(0);
    setEncoderClicks(0);
    setNotice('入力器具を初期状態へ戻しました。');
  };

  const resetMapping = () => { setInputMapping({ ...defaultInputMapping }); setNotice('標準配線へ戻しました。'); };
  const resetPolarity = () => { setInputPolarity({ ...defaultInputPolarity }); setJoystickDirection({ ...defaultJoystickDirection }); setNotice('標準極性・JOY方向へ戻しました。'); };
  const updatePolarity = (signal: ActivePolaritySignal, polarity: ActivePolarity) => {
    setInputPolarity(current => ({ ...current, [signal]: polarity }));
    setNotice(`${signal} を ACTIVE ${polarity} にしました。`);
  };
  const updateJoystickDirection = (axis: 'X' | 'Y', direction: JoystickDirection['X'] | JoystickDirection['Y']) => {
    setJoystickDirection(current => ({ ...current, [axis]: direction } as JoystickDirection));
    setNotice(`JOY ${axis} の最大値方向を ${direction.includes('LEFT') ? '左' : direction.includes('RIGHT') ? '右' : direction.includes('DOWN') ? '下' : '上'} にしました。`);
  };
  const updateMapping = (signal: InputSignal, target: ArduinoTarget) => {
    const compatible = ['TC', 'TG', 'PH', 'ENCA', 'ENCB'].includes(signal) ? digitalArduinoTargets.includes(target) : analogArduinoTargets.includes(target);
    if (!compatible) return;
    const conflict = (Object.keys(inputMapping) as InputSignal[]).find(other => other !== signal && inputMapping[other] === target);
    if (conflict) { setNotice(`${target} は ${conflict} が使用中です。先に別ピンへ移してください。`); return; }
    setInputMapping(current => ({ ...current, [signal]: target }));
    setNotice(`${signal} を ${target} へ接続しました。`);
  };

  const backupSource = (reason: string) => {
    const backup: SourceBackup = { name: sourceFileName, source, savedAt: Date.now(), reason };
    localStorage.setItem(SOURCE_BACKUP_KEY, JSON.stringify(backup));
    setSourceBackup(backup);
  };

  const restoreSourceBackup = () => {
    if (!sourceBackup) {
      setNotice('復元できる直前のプログラムはありません。');
      return;
    }
    if (!window.confirm(`「${sourceBackup.name}」の直前バックアップへ戻しますか？`)) return;
    const current: SourceBackup = { name: sourceFileName, source, savedAt: Date.now(), reason: 'バックアップ復元前' };
    setSource(sourceBackup.source);
    setSourceFileName(sourceBackup.name);
    setSaveName(sourceBackup.name);
    localStorage.setItem(SOURCE_BACKUP_KEY, JSON.stringify(current));
    setSourceBackup(current);
    setFileMenuOpen(false);
    setNotice('直前のプログラムを復元しました。もう一度押すと復元前の内容へ戻れます。');
  };

  const openCppFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      const text = await file.text();
      const name = file.name.toLowerCase().endsWith('.cpp') ? file.name : `${file.name}.cpp`;
      if (text !== source) backupSource('CPPを開く前');
      setSource(text);
      setSourceFileName(name);
      setSaveName(name);
      setNotice(`${file.name} をそのまま読み込みました。`);
    } catch { setNotice('CPPファイルを読み込めませんでした。'); }
  };
  const saveCurrentProgram = (requestedName = sourceFileName) => {
    const name = normalizeProgramName(requestedName);
    const key = name.toLocaleLowerCase();
    const existing = programSaves.find(item => item.name.toLocaleLowerCase() === key);
    const next: ProgramSave = { name, source, savedAt: Date.now() };
    setProgramSaves(current => [next, ...current.filter(item => item.name.toLocaleLowerCase() !== key)].slice(0, 30));
    setSourceFileName(name);
    setSaveName(name);
    setNotice(existing ? `${name} を上書き保存しました。` : `${name} を保存しました。`);
  };
  const loadProgramSave = (saved: ProgramSave) => {
    if (source !== saved.source && !window.confirm(`現在の編集中プログラムから「${saved.name}」へ切り替えますか？`)) return;
    if (source !== saved.source) backupSource('保存データ読込前');
    setSource(saved.source);
    setSourceFileName(saved.name);
    setSaveName(saved.name);
    setSaveManagerOpen(false);
    setNotice(`${saved.name} を読み込みました。`);
  };
  const deleteProgramSave = (saved: ProgramSave) => {
    if (!window.confirm(`保存した「${saved.name}」を削除しますか？`)) return;
    setProgramSaves(current => current.filter(item => item.name !== saved.name));
    setNotice(`${saved.name} を保存一覧から削除しました。`);
  };
  const exportCppFile = () => {
    const trimmed = sourceFileName.trim() || 'practice.cpp';
    const fileName = trimmed.toLowerCase().endsWith('.cpp') ? trimmed : `${trimmed}.cpp`;
    const blob = new Blob([source], { type: 'text/x-c++src;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = fileName;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    setSourceFileName(fileName);
    setSaveName(fileName);
    setNotice(`${fileName} を書き出しました。`);
  };
  const restoreSample = () => {
    if (source !== sampleSource && !window.confirm('現在のCPPをサンプルへ置き換えます。よろしいですか？')) return;
    if (source !== sampleSource) backupSource('サンプル復元前');
    setSource(sampleSource);
    setSourceFileName('practice.cpp');
    setSaveName('practice.cpp');
    setNotice('出力確認サンプルを復元しました。');
  };
  const formatNow = () => {
    const formatted = formatCpp(source);
    if (formatted !== source) backupSource('整形前');
    setSource(formatted);
    setNotice(formatted === source ? '字下げは整っています。' : '字下げとインデントを整えました。');
  };
  const run = () => {
    if (speaker.outputEnabled) void speaker.activate();
    setBuildRequest(value => value + 1);
  };
  const stop = () => setStopRequest(value => value + 1);
  const running = runStatus === 'running';
  const compiling = runStatus === 'compiling';
  const statusText = compiling ? 'COMPILING' : running ? 'RUNNING' : runStatus === 'error' ? 'ERROR' : runStatus === 'stopped' ? 'STOPPED' : 'READY';

  const encoderAHigh = (inputVoltages[inputMapping.ENCA] ?? 0) >= 3;
  const encoderBHigh = (inputVoltages[inputMapping.ENCB] ?? 0) >= 3;
  const inputPanel = <WorkbenchMonitor deviceState={deviceState} measured={measuredInputs} mapping={inputMapping} polarity={inputPolarity} joystickDirection={joystickDirection} polarityChanged={polarityChanged} encoderClicks={encoderClicks} encoderBusy={encoderBusy} encoderAHigh={encoderAHigh} encoderBHigh={encoderBHigh} mappingChanged={mappingChanged} onDeviceStateChange={handleDeviceStateChange} onRotateEncoder={rotateEncoder} onResetInputs={resetInputs} onResetMapping={resetMapping} onMappingChange={updateMapping} onResetPolarity={resetPolarity} onPolarityChange={updatePolarity} onJoystickDirectionChange={updateJoystickDirection} />;
  const outputPanel = <LiveOutputPanel snapshot={liveMega} attentionToken={attentionToken} attentionBaseline={attentionBaseline} />;
  const serialLastLine = serialMonitor.trimEnd().split(/\r?\n/).pop() || 'Serial出力待ち';

  return <div className="lab-light lab-shell h-[100dvh] overflow-hidden bg-[#f4efe6] text-[#263947]">
    <header className="app-header flex h-12 items-center border-b border-[#d8d1c7] bg-[#fffaf3]/95 px-2.5 shadow-[0_3px_12px_rgba(63,79,92,0.06)] backdrop-blur sm:px-4">
      <div className="flex min-w-0 items-center gap-1"><Code2 size={17} className="mr-1 hidden text-[#5bd6dc] sm:block" /><button type="button" onClick={() => changeView('program')} className={`mode-tab min-h-9 rounded-lg px-3 text-[10px] font-black ${view === 'program' ? 'is-active' : ''}`}>PROGRAM</button><button type="button" onClick={() => changeView('io')} className={`mode-tab min-h-9 rounded-lg px-3 text-[10px] font-black ${view === 'io' ? 'is-active' : ''}`}><SlidersHorizontal size={12} className="mr-1 inline" />I/O</button></div>
      <div className="ml-auto flex min-w-0 items-center gap-1.5"><span className={`status-chip rounded-md px-2 py-1 text-[8px] font-black ${runStatus === 'error' ? 'bg-[#f9d8d5] text-[#93433f]' : running ? 'bg-[#dceee7] text-[#3d735f]' : compiling ? 'bg-[#dcebf5] text-[#32698e]' : 'bg-[#ece8e1] text-[#73808a]'}`}>{statusText}</span>{sourceDirty && <span className="source-chip hidden rounded-md bg-[#f2e4c9] px-2 py-1 text-[8px] font-black text-[#8a692f] sm:inline">SOURCE*</span>}<button type="button" onClick={() => void speaker.toggleOutput()} className={`audio-master min-h-9 min-w-9 rounded-lg border px-2 text-[9px] font-black ${speaker.outputEnabled ? 'border-[#a8cdbd] bg-[#e7f2ed] text-[#3d735f]' : 'border-[#d6d0c7] bg-white/60 text-[#71818d]'}`} aria-label="スマホ音声出力を切り替え">{speaker.outputEnabled ? <Volume2 size={13} className="inline" /> : <VolumeX size={13} className="inline" />}<span className="ml-1 hidden sm:inline">PHONE AUDIO {speaker.outputEnabled ? 'ON' : 'OFF'}</span></button><button type="button" onClick={() => setAudioMixerOpen(true)} className="audio-mixer-button min-h-9 min-w-9 rounded-lg border border-[#d6d0c7] bg-white/65 text-[#61717e]" aria-label="DCM・SPK・STPMの音量調整"><SlidersHorizontal size={14} className="mx-auto" /></button><button type="button" onClick={() => setFileMenuOpen(value => !value)} className="file-menu-button min-h-9 min-w-9 rounded-lg border border-[#d6d0c7] bg-white/65 text-[#61717e]" aria-label="ファイル操作"><MoreHorizontal size={15} className="mx-auto" /></button></div>
      {fileMenuOpen && <div role="menu" className="file-menu-popover absolute right-2 top-11 z-[80] max-h-[calc(100dvh-3.25rem)] w-52 overflow-y-auto rounded-xl border border-[#d8d1c7] bg-[#fffdf9] p-1.5 text-[#354957] shadow-[0_14px_35px_rgba(63,79,92,0.16)]"><button type="button" onClick={() => { setSaveName(sourceFileName); setSaveManagerOpen(true); setFileMenuOpen(false); }} className="flex min-h-10 w-full items-center rounded-lg px-2.5 text-xs hover:bg-[#edf4f8]"><Save size={14} className="mr-2" />保存一覧</button><label className="flex min-h-10 cursor-pointer items-center rounded-lg px-2.5 text-xs hover:bg-[#edf4f8]"><FileUp size={14} className="mr-2" />CPPを開く<input type="file" accept=".cpp,text/plain,text/x-c++src" className="hidden" onChange={event => { void openCppFile(event.target.files?.[0]); event.currentTarget.value = ''; setFileMenuOpen(false); }} /></label><button type="button" onClick={() => { exportCppFile(); setFileMenuOpen(false); }} className="flex min-h-10 w-full items-center rounded-lg px-2.5 text-xs hover:bg-[#edf4f8]"><FileDown size={14} className="mr-2" />CPPを書き出す</button><button type="button" onClick={() => { restoreSample(); setFileMenuOpen(false); }} className="flex min-h-10 w-full items-center rounded-lg px-2.5 text-xs hover:bg-[#edf4f8]"><RotateCcw size={14} className="mr-2" />サンプルへ戻す</button><button type="button" onClick={restoreSourceBackup} disabled={!sourceBackup} className="flex min-h-10 w-full items-center rounded-lg px-2.5 text-xs hover:bg-[#edf4f8] disabled:cursor-not-allowed disabled:opacity-40"><RotateCcw size={14} className="mr-2" />ひとつ前の内容を復元</button></div>}
    </header>
    {notice && <div role="status" aria-live="polite" className="notice-toast fixed left-1/2 top-14 z-[130] w-[calc(100%-2rem)] max-w-md -translate-x-1/2 rounded-xl border border-[#9fc2d9] bg-[#eef7fc]/95 px-4 py-2 text-center text-xs font-bold text-[#315f7e] shadow-[0_12px_28px_rgba(63,90,110,0.14)] backdrop-blur">{notice}</div>}
    <main className="h-[calc(100dvh-6rem)] p-1.5 sm:h-[calc(100dvh-3rem)] sm:p-2">
      <section className={`${view === 'program' ? 'flex' : 'hidden'} program-shell mx-auto h-full max-w-[1500px] min-h-0 flex-col rounded-2xl border border-[#d9d0c4] bg-[#fffdf9] p-2.5 shadow-[0_12px_30px_rgba(73,93,110,0.07)] sm:p-3`}>
        <div className="program-toolbar flex shrink-0 flex-wrap items-center gap-1.5 pb-2"><input aria-label="CPPファイル名" value={sourceFileName} onChange={event => { setSourceFileName(event.target.value); setSaveName(event.target.value); }} className="mono min-h-9 min-w-0 flex-1 rounded-lg border border-[#d4cbbf] bg-[#f8f3eb] px-2.5 text-base font-semibold text-[#354957] outline-none focus:border-[#6f9fbe] sm:max-w-64 sm:text-xs" /><button type="button" onClick={() => saveCurrentProgram()} className="action-secondary min-h-9 rounded-lg border border-[#b9cedb] bg-[#eef5f9] px-2.5 text-[9px] font-black text-[#3d7398]"><Save size={13} className="mr-1 inline" />保存</button><button type="button" onClick={run} disabled={compiling} className="action-run min-h-9 rounded-lg bg-[#5e8fb2] px-3 text-[10px] font-black text-white shadow-sm disabled:opacity-50"><Play size={13} className="mr-1 inline" />{sourceDirty && running ? 'REBUILD' : 'BUILD & RUN'}</button><button type="button" onClick={stop} disabled={!running && !compiling} className="action-stop min-h-9 min-w-9 rounded-lg border border-[#cdd6dc] bg-white px-2 text-[#566a78] disabled:opacity-35" aria-label="停止"><Square size={13} className="mx-auto" /></button><button type="button" onClick={formatNow} className="action-secondary min-h-9 rounded-lg border border-[#c9d6df] bg-[#eef5f9] px-2.5 text-[9px] font-black text-[#3d7398]"><AlignLeft size={13} className="mr-1 inline" />整形</button>{sourceDirty && running && <span className="hidden rounded-lg bg-[#f3e5ca] px-2 py-1 text-[9px] font-black text-[#8b692f] sm:inline">旧ビルド実行中</span>}<span className="ml-auto hidden text-[9px] font-semibold text-[#83909a] md:inline">関数・変数を強調 · 自動字下げ · 演算子の前後も自動整形</span></div>
        <AvrWorkbench compact showControls={false} source={source} circuitVoltages={inputVoltages} inputVoltageProvider={sampleInputVoltages} buildRequest={buildRequest} stopRequest={stopRequest} onStatusChange={setRunStatus} onBuiltSource={setBuiltSource} onSnapshot={handleMegaSnapshot} onSerialOutput={setSerialMonitor} onStepperStep={speaker.playStepperStep} />
        <div className="mt-2 min-h-0 min-w-0 flex-1 overflow-hidden"><CppEditor value={source} onChange={setSource} /></div>
      </section>
      <section className={`${view === 'io' ? 'grid' : 'hidden'} io-workspace io-shell relative mx-auto h-full max-w-[1500px] min-h-0 grid-rows-[40px_minmax(0,1fr)_32px] gap-1.5`}> 
        <div className="io-toolbar io-toolbar-scroll flex min-w-0 items-center gap-1.5 overflow-x-auto rounded-xl border border-[#d8d0c4] bg-[#fffaf3] px-2 shadow-[0_5px_14px_rgba(74,90,105,0.06)]"><button type="button" onClick={run} disabled={compiling} className="min-h-8 rounded-lg bg-[#5e8fb2] px-2.5 text-[9px] font-black text-white disabled:opacity-50"><Play size={12} className="mr-1 inline" />{sourceDirty && running ? 'REBUILD' : 'RUN'}</button><button type="button" onClick={stop} disabled={!running && !compiling} className="min-h-8 min-w-8 rounded-lg border border-[#cdd6dc] bg-white text-[#566a78] disabled:opacity-35" aria-label="停止"><Square size={12} className="mx-auto" /></button><span className="io-file-name min-w-0 flex-1 truncate text-[9px] font-semibold text-[#6f7d82]">{sourceFileName}</span>{mappingChanged && <span className="ml-auto shrink-0 rounded bg-[#f3e5ca] px-1.5 py-1 text-[8px] font-black text-[#8b692f]">配線変更</span>}<span className={`io-status-pill shrink-0 rounded px-1.5 py-1 text-[8px] font-black ${speaker.outputEnabled ? 'bg-[#e2efe9] text-[#477865]' : 'bg-[#ece8e1] text-[#7b858c]'}`}>端末音声 {speaker.outputEnabled ? 'ON' : 'OFF'}</span><span className={`io-status-pill shrink-0 rounded px-1.5 py-1 text-[8px] font-black ${speaker.engineLoaded && speaker.stepperLoaded ? 'bg-[#dceee7] text-[#477865]' : 'bg-[#fae5e2] text-[#93433f]'}`}>音源 DCM {speaker.engineLoaded ? '✓' : '…'} · STPM {speaker.stepperLoaded ? '✓' : '…'}</span></div>
        <div className="io-panels grid min-h-0 grid-cols-2 gap-1.5 overflow-hidden lg:grid-cols-[0.9fr_1.1fr]"><div className="min-h-0 min-w-0 overflow-hidden">{inputPanel}</div><div className="min-h-0 min-w-0 overflow-hidden">{outputPanel}</div></div>
        <button type="button" onClick={() => setSerialExpanded(true)} className="serial-dock grid min-h-0 min-w-0 grid-cols-[52px_minmax(0,1fr)_24px] items-center overflow-hidden rounded-lg border border-[#bfd0db] bg-[#eef5f9] px-1.5 text-left text-[#354957] shadow-[0_3px_10px_rgba(74,90,105,0.04)]" aria-label="シリアルモニターを開く">
          <span className="text-[7px] font-black tracking-[0.1em] text-[#3d7398]">SERIAL <span className={running ? 'text-[#477865]' : 'text-[#87939b]'}>{running ? '●' : '○'}</span></span>
          <span className="mono min-w-0 truncate text-[8px] text-[#3f6555]">{serialLastLine}</span>
          <span className="text-center text-[9px] font-black text-[#66808f]">▲</span>
        </button>
        {serialExpanded && <section className="serial-panel absolute inset-x-0 bottom-0 z-40 h-[128px] rounded-xl border border-[#9db9ca] bg-[#f7fbfd]/98 p-2 text-[#354957] shadow-[0_-10px_28px_rgba(55,75,90,0.16)] backdrop-blur sm:h-[160px]">
          <div className="flex h-7 items-center justify-between"><div className="flex items-center gap-2"><span className="text-[9px] font-black tracking-[0.12em] text-[#3d7398]">SERIAL MONITOR</span><span className={`text-[7px] font-black ${running ? 'text-[#477865]' : 'text-[#87939b]'}`}>{running ? '● LIVE' : '○ WAIT'}</span></div><button type="button" onClick={() => setSerialExpanded(false)} className="min-h-7 rounded-md border border-[#c7d5de] bg-white px-2 text-[8px] font-black text-[#5f7380]">▼ 閉じる</button></div>
          <pre ref={serialPreRef} className="mono mt-1 h-[calc(100%-2rem)] min-h-0 overflow-auto whitespace-pre-wrap break-words rounded-lg border border-[#d3dfe5] bg-white/75 px-2 py-1.5 text-[9px] leading-4 text-[#3f6555]">{serialMonitor || 'Serial出力待ち'}</pre>
        </section>}
      </section>
    </main>
    {saveManagerOpen && <div className="modal-backdrop fixed inset-0 z-[155] flex items-center justify-center overflow-y-auto bg-[#dbe4e9]/75 p-3 backdrop-blur-sm"><div role="dialog" aria-modal="true" className="modal-card w-full max-w-lg rounded-2xl border border-[#d9d0c4] bg-[#fffaf3] p-3 text-[#354957] shadow-[0_22px_55px_rgba(60,77,91,0.18)]"><div className="flex items-start justify-between gap-3"><div><h2 className="font-black">プログラム保存</h2><p className="mt-1 text-[10px] leading-4 text-[#778590]">編集中の内容は自動保持されます。ここでは名前付きの保存データを残せます。</p></div><button type="button" onClick={() => setSaveManagerOpen(false)} className="min-h-9 min-w-9 rounded-lg border border-[#d6d0c7] bg-white" aria-label="保存一覧を閉じる"><X size={15} className="mx-auto" /></button></div><div className="mt-3 grid grid-cols-[minmax(0,1fr)_auto] gap-1.5"><input aria-label="保存するプログラム名" value={saveName} onChange={event => setSaveName(event.target.value)} className="mono min-h-10 min-w-0 rounded-lg border border-[#c8d7df] bg-white px-2 text-base outline-none focus:border-[#6f9fbe] sm:text-xs" /><button type="button" onClick={() => saveCurrentProgram(saveName)} className="min-h-10 rounded-lg bg-[#5e8fb2] px-3 text-[10px] font-black text-white"><Save size={13} className="mr-1 inline" />この名前で保存</button></div><div className="mt-3 max-h-[52vh] space-y-1.5 overflow-y-auto">{programSaves.length === 0 ? <div className="rounded-xl border border-dashed border-[#cdd7dd] bg-white/55 p-5 text-center text-[11px] font-semibold text-[#87939b]">まだ名前付き保存はありません。</div> : programSaves.map(saved => <div key={saved.name} className="grid grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-1.5 rounded-xl border border-[#ded7cd] bg-white/70 p-2"><button type="button" onClick={() => loadProgramSave(saved)} className="min-w-0 text-left"><div className="mono truncate text-[11px] font-black text-[#354957]">{saved.name}</div><div className="mt-0.5 text-[8px] font-semibold text-[#8a9297]">{new Date(saved.savedAt).toLocaleString('ja-JP', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })} · {saved.source.split(/\r?\n/).length}行</div></button><button type="button" onClick={() => loadProgramSave(saved)} className="min-h-9 rounded-lg border border-[#b9cedb] bg-[#eef5f9] px-2 text-[9px] font-black text-[#3d7398]">読込</button><button type="button" onClick={() => deleteProgramSave(saved)} className="min-h-9 min-w-9 rounded-lg border border-[#e0c7c3] bg-[#fff5f3] text-[#a05b52]" aria-label={`${saved.name}を削除`}><Trash2 size={13} className="mx-auto" /></button></div>)}</div></div></div>}
    <nav className="fixed inset-x-2 bottom-[max(0.35rem,env(safe-area-inset-bottom))] z-[145] grid h-10 grid-cols-2 gap-1 rounded-xl border border-[#cbd5db] bg-[#fffaf3]/95 p-1 shadow-[0_10px_30px_rgba(55,75,90,0.18)] backdrop-blur sm:hidden" aria-label="画面切り替え">
      <button type="button" onClick={() => changeView('program')} className={`rounded-lg text-[10px] font-black ${view === 'program' ? 'bg-[#dcebf5] text-[#2f668d]' : 'text-[#73828d]'}`}>PROGRAM</button>
      <button type="button" onClick={() => changeView('io')} className={`rounded-lg text-[10px] font-black ${view === 'io' ? 'bg-[#eadfcf] text-[#765d43]' : 'text-[#73828d]'}`}>I/O</button>
    </nav>
    {audioMixerOpen && <div className="modal-backdrop fixed inset-0 z-[158] flex items-center justify-center overflow-y-auto bg-[#dbe4e9]/75 p-4 backdrop-blur-sm"><div role="dialog" aria-modal="true" className="modal-card max-h-[calc(100dvh-2rem)] w-full max-w-sm overflow-y-auto rounded-2xl border border-[#d9d0c4] bg-[#fffaf3] p-4 text-[#354957] shadow-[0_22px_55px_rgba(60,77,91,0.18)]"><div className="flex items-start justify-between gap-3"><div><div className="flex items-center gap-2 font-black"><SlidersHorizontal size={18} className="text-[#5e8fb2]" />音量・DCM音源</div><p className="mt-1 text-[10px] leading-4 text-[#778590]">DCM音源の種類と、DCM・SPK・STPMの音量を調整できます。設定はこの端末に保存されます。</p></div><button type="button" onClick={() => setAudioMixerOpen(false)} className="min-h-9 min-w-9 rounded-lg border border-[#d6d0c7] bg-white" aria-label="音量ミキサーを閉じる"><X size={15} className="mx-auto" /></button></div><label className="mt-4 block"><div className="mb-1 text-xs font-black">DCM音源</div><select value={speaker.dcmSound} onChange={event => speaker.setDcmSound(event.target.value as typeof speaker.dcmSound)} className="min-h-10 w-full rounded-lg border border-[#c8d7df] bg-white px-2 text-sm font-bold text-[#354957] outline-none focus:border-[#6f9fbe]" aria-label="DCM音源を選択">{speaker.dcmSoundOptions.map(option => <option key={option.id} value={option.id}>{option.label}</option>)}</select><div className="mt-1 text-[9px] leading-4 text-[#7a8790]">選んだ音源も現在と同じく、DCMの回転速度に合わせて音の位置を変えて再生します。</div></label><div className="mt-4 space-y-4">{([['DCM', speaker.dcmVolume, speaker.setDcmVolume], ['SPK', speaker.spkVolume, speaker.setSpkVolume], ['STPM', speaker.stpmVolume, speaker.setStpmVolume]] as const).map(([label, value, setter]) => <label key={label} className="block"><div className="mb-1 flex items-center justify-between text-xs font-black"><span>{label}</span><span className="mono text-[#5e8fb2]">{value}%</span></div><input type="range" min="0" max="100" step="1" value={value} onChange={event => setter(Number(event.target.value))} className="w-full accent-[#5e8fb2]" aria-label={`${label}音量`} /></label>)}</div><div className="mt-4 rounded-lg bg-[#eef5f9] px-3 py-2 text-[10px] font-semibold leading-4 text-[#607784]">DCMにはクリックノイズを抑えるフェード処理とピーク抑制を追加しています。PHONE AUDIOがOFFのときは3系統すべてミュートされます。</div></div></div>}
    {speaker.promptOpen && <div className="modal-backdrop fixed inset-0 z-[160] flex items-center justify-center overflow-y-auto bg-[#dbe4e9]/75 p-4 backdrop-blur-sm"><div role="dialog" aria-modal="true" className="modal-card max-h-[calc(100dvh-2rem)] w-full max-w-sm overflow-y-auto rounded-2xl border border-[#d9d0c4] bg-[#fffaf3] p-4 text-[#354957] shadow-[0_22px_55px_rgba(60,77,91,0.18)]"><div className="flex items-start justify-between gap-3"><div><div className="flex items-center gap-2 font-black"><Volume2 size={18} className="text-[#4f8770]" />スマホへの音声出力を許可しますか？</div><p className="mt-2 text-xs leading-5 text-[#72808a]">許可確認は初回だけです。SPK音、DCMの回転速度に連動したエンジン音、STPMのステップ音を再生します。上部のPHONE AUDIOでまとめてON/OFFでき、隣の音量ボタンから個別調整できます。</p></div><button type="button" onClick={speaker.deny} className="min-h-9 min-w-9 rounded-lg border border-[#d6d0c7] bg-white" aria-label="閉じる"><X size={15} className="mx-auto" /></button></div>{speaker.error && <div className="mt-3 rounded-lg bg-[#fae5e2] p-2 text-xs font-semibold text-[#93433f]">{speaker.error}</div>}<div className="mt-4 grid grid-cols-2 gap-2"><button type="button" onClick={speaker.deny} className="min-h-11 rounded-xl border border-[#d6d0c7] bg-white text-xs font-bold text-[#657580]">音なしで使う</button><button type="button" onClick={() => void speaker.allow()} className="min-h-11 rounded-xl bg-[#5e8fb2] text-xs font-black text-white">音声を許可</button></div></div></div>}
  </div>;
}

export default ProgramLab;
