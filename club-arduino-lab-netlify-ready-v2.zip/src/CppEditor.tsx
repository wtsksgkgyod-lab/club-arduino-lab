import { memo, useMemo, useRef, useState } from 'react';
import CodeMirror from '@uiw/react-codemirror';
import { cpp } from '@codemirror/lang-cpp';
import { indentWithTab } from '@codemirror/commands';
import { indentUnit } from '@codemirror/language';
import { Decoration, EditorView, keymap, ViewPlugin, type DecorationSet, type ViewUpdate } from '@codemirror/view';

const cppKeywords = new Set([
  'alignas', 'alignof', 'and', 'asm', 'auto', 'bool', 'break', 'case', 'catch', 'char', 'class', 'const', 'constexpr', 'continue', 'default', 'delete', 'do', 'double', 'else', 'enum', 'explicit', 'extern', 'false', 'float', 'for', 'friend', 'if', 'inline', 'int', 'long', 'namespace', 'new', 'noexcept', 'not', 'nullptr', 'operator', 'or', 'private', 'protected', 'public', 'register', 'return', 'short', 'signed', 'sizeof', 'static', 'struct', 'switch', 'template', 'this', 'throw', 'true', 'try', 'typedef', 'typename', 'union', 'unsigned', 'using', 'virtual', 'void', 'volatile', 'while', 'xor',
]);
const compactOperators = new Set(['++', '--', '->', '::']);
const isIdentifierChar = (char: string | undefined) => Boolean(char && /[A-Za-z0-9_]/.test(char));

function identifierAt(text: string, rawPosition: number) {
  if (!text) return '';
  let position = Math.min(Math.max(0, rawPosition), text.length - 1);
  if (!isIdentifierChar(text[position]) && position > 0 && isIdentifierChar(text[position - 1])) position -= 1;
  if (!isIdentifierChar(text[position])) return '';
  let from = position;
  let to = position + 1;
  while (from > 0 && isIdentifierChar(text[from - 1])) from -= 1;
  while (to < text.length && isIdentifierChar(text[to])) to += 1;
  const symbol = text.slice(from, to);
  return /^[A-Za-z_][A-Za-z0-9_]*$/.test(symbol) && !cppKeywords.has(symbol) ? symbol : '';
}

function symbolDecorations(view: EditorView): DecorationSet {
  const text = view.state.doc.toString();
  if (!text) return Decoration.set([]);
  let position = Math.min(view.state.selection.main.head, text.length - 1);
  if (!isIdentifierChar(text[position]) && position > 0 && isIdentifierChar(text[position - 1])) position -= 1;
  if (!isIdentifierChar(text[position])) return Decoration.set([]);
  let from = position;
  let to = position + 1;
  while (from > 0 && isIdentifierChar(text[from - 1])) from -= 1;
  while (to < text.length && isIdentifierChar(text[to])) to += 1;
  const symbol = text.slice(from, to);
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(symbol) || cppKeywords.has(symbol)) return Decoration.set([]);
  const ranges = [];
  for (const visible of view.visibleRanges) {
    let cursor = visible.from;
    while (cursor < visible.to) {
      const index = text.indexOf(symbol, cursor);
      if (index < 0 || index >= visible.to) break;
      const end = index + symbol.length;
      if (!isIdentifierChar(text[index - 1]) && !isIdentifierChar(text[end])) {
        const current = index === from && end === to;
        ranges.push(Decoration.mark({ class: current ? 'cm-symbol-current' : 'cm-symbol-match' }).range(index, end));
      }
      cursor = Math.max(end, index + 1);
    }
  }
  return Decoration.set(ranges, true);
}

const symbolHighlighter = ViewPlugin.fromClass(class {
  decorations: DecorationSet;
  constructor(view: EditorView) { this.decorations = symbolDecorations(view); }
  update(update: ViewUpdate) {
    if (update.docChanged || update.selectionSet || update.viewportChanged) this.decorations = symbolDecorations(update.view);
  }
}, { decorations: plugin => plugin.decorations });

type BraceState = { inBlockComment: boolean };
function braceDelta(line: string, state: BraceState) {
  let opens = 0;
  let closes = 0;
  let quote: '"' | "'" | null = null;
  let escaped = false;
  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    const next = line[index + 1];
    if (state.inBlockComment) {
      if (char === '*' && next === '/') { state.inBlockComment = false; index += 1; }
      continue;
    }
    if (quote) {
      if (escaped) { escaped = false; continue; }
      if (char === '\\') { escaped = true; continue; }
      if (char === quote) quote = null;
      continue;
    }
    if (char === '/' && next === '/') break;
    if (char === '/' && next === '*') { state.inBlockComment = true; index += 1; continue; }
    if (char === '"' || char === "'") { quote = char; continue; }
    if (char === '{') opens += 1;
    if (char === '}') closes += 1;
  }
  return opens - closes;
}

function commentStart(line: string) {
  let quote: '"' | "'" | null = null;
  let escaped = false;
  for (let index = 0; index < line.length - 1; index += 1) {
    const char = line[index];
    const next = line[index + 1];
    if (quote) {
      if (escaped) { escaped = false; continue; }
      if (char === '\\') { escaped = true; continue; }
      if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || char === "'") { quote = char; continue; }
    if ((char === '/' && next === '/') || (char === '/' && next === '*')) return index;
  }
  return -1;
}

function normalizeSpacing(line: string) {
  const marker = commentStart(line);
  const code = marker >= 0 ? line.slice(0, marker) : line;
  const comment = marker >= 0 ? line.slice(marker).trimStart() : '';
  const literals: string[] = [];
  let work = code.replace(/("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')/g, match => {
    const token = `__CPP_LITERAL_${literals.length}__`;
    literals.push(match);
    return token;
  });
  work = work.replace(/\s+/g, ' ').trim();
  work = work.replace(/\s*(\+\+|--|->|::|<<=|>>=|\+=|-=|\*=|\/=|%=|&=|\|=|\^=|==|!=|<=|>=|&&|\|\||<<|>>|=|\+|-|\*|\/|%|<|>|&|\||\^|\?|:)\s*/g, (_match, operator: string) => compactOperators.has(operator) ? operator : ` ${operator} `);
  work = work.replace(/\s*,\s*/g, ', ');
  work = work.replace(/\s*;\s*/g, '; ');
  work = work.replace(/\b(if|for|while|switch|catch)\s*\(/g, '$1 (');
  work = work.replace(/\(\s+/g, '(').replace(/\s+\)/g, ')');
  work = work.replace(/\[\s+/g, '[').replace(/\s+\]/g, ']');
  work = work.replace(/\s*\{\s*$/g, ' {');
  work = work.replace(/\s+/g, ' ').trim();
  work = work.replace(/;\s*$/g, ';');
  work = work.replace(/([=(,:?])\s+-\s+([A-Za-z0-9_])/g, '$1 -$2');
  work = work.replace(/\breturn\s+-\s+([A-Za-z0-9_])/g, 'return -$1');
  work = work.replace(/__CPP_LITERAL_(\d+)__/g, (_match, index: string) => literals[Number(index)] ?? '');
  if (!comment) return work;
  return work ? `${work} ${comment}` : comment;
}

export function formatCpp(source: string) {
  const normalized = source.replace(/\r\n?/g, '\n');
  const hadFinalNewline = normalized.endsWith('\n');
  const lines = normalized.split('\n');
  const state: BraceState = { inBlockComment: false };
  let indent = 0;
  const formatted = lines.map(rawLine => {
    const trimmed = rawLine.trim();
    if (!trimmed) return '';
    if (trimmed.startsWith('#')) return trimmed;
    const preserveSpacing = state.inBlockComment || trimmed.startsWith('//') || trimmed.startsWith('/*') || trimmed.startsWith('*');
    const spaced = preserveSpacing ? trimmed : normalizeSpacing(trimmed);
    const leadingClose = spaced.startsWith('}') ? 1 : 0;
    const lineIndent = Math.max(0, indent - leadingClose);
    const output = `${'  '.repeat(lineIndent)}${spaced}`;
    indent = Math.max(0, indent + braceDelta(spaced, state));
    return output;
  });
  const result = formatted.join('\n');
  return hadFinalNewline && !result.endsWith('\n') ? `${result}\n` : result;
}

type Props = { value: string; onChange: (value: string) => void };
type ReplaceScope = 'range' | 'document';

function CppEditor({ value, onChange }: Props) {
  const viewRef = useRef<EditorView | null>(null);
  const [replaceOpen, setReplaceOpen] = useState(false);
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [scope, setScope] = useState<ReplaceScope>('document');
  const [wholeWord, setWholeWord] = useState(true);
  const [selection, setSelection] = useState({ from: 0, to: 0 });
  const [startLine, setStartLine] = useState(1);
  const [endLine, setEndLine] = useState(1);
  const [replaceMessage, setReplaceMessage] = useState('');

  const extensions = useMemo(() => [
    cpp(), indentUnit.of('  '), keymap.of([indentWithTab]), symbolHighlighter,
    EditorView.scrollMargins.of(() => ({ top: 10, bottom: 28, left: 10, right: 36 })),
    EditorView.updateListener.of(update => {
      if (update.selectionSet || update.docChanged) {
        const main = update.state.selection.main;
        setSelection({ from: main.from, to: main.to });
      }
    }),
    EditorView.contentAttributes.of({ 'aria-label': 'CPPソースエディタ', autocapitalize: 'off', autocomplete: 'off', spellcheck: 'false' }),
  ], []);

  const normalizedLines = () => {
    const view = viewRef.current;
    if (!view) return { first: 1, last: 1 };
    const max = view.state.doc.lines;
    const first = Math.max(1, Math.min(max, Math.min(startLine, endLine)));
    const last = Math.max(first, Math.min(max, Math.max(startLine, endLine)));
    return { first, last };
  };

  const useSelectionAsRange = () => {
    const view = viewRef.current;
    if (!view || selection.from === selection.to) {
      setReplaceMessage('先にコードをドラッグ選択してください');
      return;
    }
    const first = view.state.doc.lineAt(Math.min(selection.from, selection.to)).number;
    const lastPosition = Math.max(Math.min(selection.from, selection.to), Math.max(selection.from, selection.to) - 1);
    const last = view.state.doc.lineAt(lastPosition).number;
    setStartLine(first);
    setEndLine(last);
    setScope('range');
    setReplaceMessage(`L${first}〜L${last}を対象に設定`);
  };

  const showRange = () => {
    const view = viewRef.current;
    if (!view) return;
    const { first, last } = normalizedLines();
    setStartLine(first);
    setEndLine(last);
    view.dispatch({ selection: { anchor: view.state.doc.line(first).from, head: view.state.doc.line(last).to }, scrollIntoView: true });
    view.focus();
  };

  const openReplace = () => {
    const view = viewRef.current;
    if (view) {
      const main = view.state.selection.main;
      const selected = view.state.sliceDoc(main.from, main.to);
      const symbol = /^[A-Za-z_][A-Za-z0-9_]*$/.test(selected) ? selected : identifierAt(view.state.doc.toString(), main.head);
      if (symbol) setFindText(symbol);
      setSelection({ from: main.from, to: main.to });
      if (main.from !== main.to) {
        const first = view.state.doc.lineAt(main.from).number;
        const last = view.state.doc.lineAt(Math.max(main.from, main.to - 1)).number;
        setStartLine(first);
        setEndLine(last);
        setScope('range');
      } else {
        setScope('document');
      }
    }
    setReplaceMessage('');
    setReplaceOpen(true);
  };

  const replaceAll = () => {
    const view = viewRef.current;
    const query = findText;
    if (!view || !query) return;
    const text = view.state.doc.toString();
    const lines = normalizedLines();
    const from = scope === 'range' ? view.state.doc.line(lines.first).from : 0;
    const to = scope === 'range' ? view.state.doc.line(lines.last).to : text.length;
    const changes: Array<{ from: number; to: number; insert: string }> = [];
    let cursor = from;
    while (cursor < to) {
      const index = text.indexOf(query, cursor);
      if (index < 0 || index + query.length > to) break;
      const end = index + query.length;
      const boundaryOk = !wholeWord || (!isIdentifierChar(text[index - 1]) && !isIdentifierChar(text[end]));
      if (boundaryOk) changes.push({ from: index, to: end, insert: replaceText });
      cursor = Math.max(end, index + 1);
    }
    if (!changes.length) {
      setReplaceMessage('一致なし');
      return;
    }
    view.dispatch({ changes });
    setStartLine(lines.first);
    setEndLine(lines.last);
    setReplaceMessage(`${changes.length}件置換しました`);
    view.focus();
  };

  return <div className="cpp-editor-shell relative min-h-0 flex-1 overflow-hidden rounded-xl border border-[#c9d6df] bg-[#fffdf8]">
    <button type="button" onClick={openReplace} className="editor-replace-button absolute right-2 top-2 z-20 min-h-8 rounded-lg border border-[#b9cedb] bg-[#f5fbfe]/95 px-3 text-[10px] font-black text-[#356f94] shadow-sm">置換</button>
    {replaceOpen && <div className="cpp-replace-panel replace-tool-panel absolute left-1 right-1 top-1 z-30 max-h-[calc(100%-0.5rem)] overflow-y-auto rounded-xl border border-[#afc8d8] bg-[#fbfdfe]/98 p-2 shadow-[0_12px_28px_rgba(63,90,110,0.18)] sm:left-2 sm:right-2 sm:top-2">
      <div className="grid grid-cols-2 gap-1.5">
        <input aria-label="置換する文字" value={findText} onChange={event => setFindText(event.target.value)} placeholder="検索 count" className="mono min-h-10 min-w-0 rounded-lg border border-[#c8d7df] bg-white px-2 text-[12px] outline-none focus:border-[#6f9fbe]" />
        <input aria-label="置換後の文字" value={replaceText} onChange={event => setReplaceText(event.target.value)} placeholder="置換後 through" className="mono min-h-10 min-w-0 rounded-lg border border-[#c8d7df] bg-white px-2 text-[12px] outline-none focus:border-[#6f9fbe]" />
      </div>
      <div className="mt-1.5 grid grid-cols-[auto_auto_minmax(0,1fr)] items-center gap-1 text-[9px] font-bold text-[#71818d]">
        <button type="button" onClick={() => setScope('document')} className={`min-h-8 rounded-lg border px-2 ${scope === 'document' ? 'border-[#7fa8c2] bg-[#e5f0f6] text-[#356f94]' : 'border-[#d4dce0] bg-white'}`}>全体</button>
        <button type="button" onClick={() => setScope('range')} className={`min-h-8 rounded-lg border px-2 ${scope === 'range' ? 'border-[#7fa8c2] bg-[#e5f0f6] text-[#356f94]' : 'border-[#d4dce0] bg-white'}`}>行範囲</button>
        {scope === 'range' ? <div className="grid min-w-0 grid-cols-[1fr_auto_1fr] items-center gap-1"><input aria-label="置換開始行" type="number" min="1" value={startLine} onChange={event => setStartLine(Number(event.target.value) || 1)} className="mono min-h-8 min-w-0 rounded-md border border-[#cbd8df] bg-white px-1 text-center text-[11px]" /><span>〜</span><input aria-label="置換終了行" type="number" min="1" value={endLine} onChange={event => setEndLine(Number(event.target.value) || 1)} className="mono min-h-8 min-w-0 rounded-md border border-[#cbd8df] bg-white px-1 text-center text-[11px]" /></div> : <div className="truncate text-right">ファイル全体</div>}
      </div>
      <div className="mt-1.5 flex flex-wrap items-center gap-1 text-[9px] font-bold text-[#71818d]">
        <button type="button" disabled={selection.from === selection.to} onClick={useSelectionAsRange} className="min-h-8 rounded-lg border border-[#d4dce0] bg-white px-2 disabled:opacity-35">選択中を使う</button>
        <button type="button" disabled={scope !== 'range'} onClick={showRange} className="min-h-8 rounded-lg border border-[#d4dce0] bg-white px-2 disabled:opacity-35">範囲を見る</button>
        <label className="flex min-h-8 items-center gap-1 rounded-lg border border-[#d4dce0] bg-white px-2"><input type="checkbox" checked={wholeWord} onChange={event => setWholeWord(event.target.checked)} />単語単位</label>
        <span className="ml-auto min-w-0 truncate text-[8px] text-[#66808f]">{replaceMessage}</span>
      </div>
      <div className="mt-1.5 grid grid-cols-[1fr_auto] gap-1.5"><button type="button" onClick={replaceAll} className="min-h-10 rounded-lg bg-[#5e8fb2] px-3 text-[11px] font-black text-white">この範囲を一括置換</button><button type="button" onClick={() => setReplaceOpen(false)} className="min-h-10 rounded-lg border border-[#ccd7dd] bg-white px-3 text-[10px] font-black text-[#627783]">閉じる</button></div>
    </div>}
    <CodeMirror className="h-full min-h-0" value={value} height="100%" theme="dark" extensions={extensions} onCreateEditor={view => { viewRef.current = view; const main = view.state.selection.main; setSelection({ from: main.from, to: main.to }); }} onChange={onChange} basicSetup={{ lineNumbers: true, highlightActiveLineGutter: true, highlightActiveLine: true, foldGutter: true, bracketMatching: true, closeBrackets: true, indentOnInput: true }} />
  </div>;
}

export default memo(CppEditor);
