type Props = {
  value: number;
  label: string;
};

const knownPatterns: Record<number, string> = {
  0x00: 'OFF',
  0x3f: '0',
  0x06: '1',
  0x5b: '2',
  0x4f: '3',
  0x66: '4',
  0x6d: '5',
  0x7d: '6',
  0x07: '7',
  0x7f: '8',
  0x6f: '9',
  0x77: 'A',
  0x7c: 'b',
  0x39: 'C',
  0x58: 'c',
  0x5e: 'd',
  0x79: 'E',
  0x71: 'F',
  0x76: 'H',
  0x38: 'L',
};

export function segmentText(value: number) {
  const base = value & 0x7f;
  const decimal = (value & 0x80) !== 0;
  if (base === 0 && decimal) return '.';
  const text = knownPatterns[base] ?? `0x${base.toString(16).toUpperCase().padStart(2, '0')}`;
  return decimal ? `${text}.` : text;
}

function SevenSegmentDigit({ value, label }: Props) {
  const active = (bit: number) => (value & (1 << bit)) !== 0;
  const fill = (bit: number) => (active(bit) ? '#fb7185' : '#232936');
  const glow = (bit: number) => (active(bit) ? 'drop-shadow(0 0 5px rgba(251,113,133,.85))' : 'none');

  return (
    <div className="min-w-0 rounded-xl bg-black/30 p-2 text-center">
      <div className="text-[10px] font-semibold text-slate-500">{label}</div>
      <svg viewBox="0 0 180 260" className="mx-auto mt-1 h-28 w-auto" role="img" aria-label={`${label} 7セグ ${segmentText(value)}`}>
        <polygon points="45,20 135,20 150,35 135,50 45,50 30,35" fill={fill(0)} style={{ filter: glow(0) }} />
        <polygon points="145,45 160,60 160,115 145,130 130,115 130,60" fill={fill(1)} style={{ filter: glow(1) }} />
        <polygon points="145,135 160,150 160,205 145,220 130,205 130,150" fill={fill(2)} style={{ filter: glow(2) }} />
        <polygon points="45,210 135,210 150,225 135,240 45,240 30,225" fill={fill(3)} style={{ filter: glow(3) }} />
        <polygon points="35,135 50,150 50,205 35,220 20,205 20,150" fill={fill(4)} style={{ filter: glow(4) }} />
        <polygon points="35,45 50,60 50,115 35,130 20,115 20,60" fill={fill(5)} style={{ filter: glow(5) }} />
        <polygon points="45,115 135,115 150,130 135,145 45,145 30,130" fill={fill(6)} style={{ filter: glow(6) }} />
        <circle cx="168" cy="226" r="9" fill={fill(7)} style={{ filter: glow(7) }} />
      </svg>
      <div className="mt-1 text-sm font-bold text-red-200">{segmentText(value)}</div>
      <div className="mono text-[10px] text-slate-500">0x{value.toString(16).toUpperCase().padStart(2, '0')}</div>
    </div>
  );
}

export default SevenSegmentDigit;
