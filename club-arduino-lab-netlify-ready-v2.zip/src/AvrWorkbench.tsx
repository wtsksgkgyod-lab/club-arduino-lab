import { useEffect, useRef, useState } from 'react';
import { ChevronDown, ChevronUp, Cpu, Gauge, Play, Square, TerminalSquare } from 'lucide-react';
import { analogValue, digitalLabel } from './sim';
import type { ArduinoTarget } from './sim';
import { buildMegaHex, MegaRunner } from './avrMega';
import type { MegaSnapshot } from './avrMega';

export type WorkbenchStatus = 'idle' | 'compiling' | 'running' | 'stopped' | 'error';

type Props = {
  source: string;
  circuitVoltages: Partial<Record<ArduinoTarget, number | null>>;
  inputVoltageProvider?: () => Partial<Record<ArduinoTarget, number | null>>;
  onSnapshot?: (snapshot: MegaSnapshot | null) => void;
  onOpenHardware?: () => void;
  onStatusChange?: (status: WorkbenchStatus) => void;
  onBuiltSource?: (source: string) => void;
  onSerialOutput?: (text: string) => void;
  onStepperStep?: (simMs: number) => void;
  buildRequest?: number;
  stopRequest?: number;
  showControls?: boolean;
  compact?: boolean;
};

const inputDigitalTargets: ArduinoTarget[] = [
  'D1',
  'D3',
  'D5',
  'D7',
  'D9',
  'D20',
  'D21',
];
const inputAnalogTargets: ArduinoTarget[] = ['A2', 'A4', 'A6', 'A8', 'A10'];

function localizeCompilerLine(line: string) {
  let text = line;
  const replacements: Array<[RegExp, string]> = [
    [/error: ['‘]([^'’]+)['’] was not declared in this scope/i, "エラー: '$1' はこの範囲で宣言されていません。宣言位置やスペルを確認してください。"],
    [/error: ['‘]([^'’]+)['’] does not name a type/i, "エラー: '$1' は型として認識できません。型名や宣言順を確認してください。"],
    [/error: expected ['‘];['’] before ['‘]([^'’]+)['’] token/i, "エラー: '$1' の前に ';' が必要です。"],
    [/error: expected ['‘]}['’] at end of input/i, "エラー: プログラムの最後までに '}' が不足しています。"],
    [/error: expected ['‘]([^'’]+)['’] before ['‘]([^'’]+)['’] token/i, "エラー: '$2' の前に '$1' が必要です。"],
    [/error: expected primary-expression before ['‘]([^'’]+)['’] token/i, "エラー: '$1' の前の式が正しくありません。括弧・演算子・値を確認してください。"],
    [/error: too few arguments to function ['‘]([^'’]+)['’]/i, "エラー: 関数 '$1' に渡す引数が足りません。"],
    [/error: too many arguments to function ['‘]([^'’]+)['’]/i, "エラー: 関数 '$1' に渡している引数が多すぎます。"],
    [/error: no matching function for call to ['‘]([^'’]+)['’]/i, "エラー: '$1' に一致する関数がありません。引数の数や型を確認してください。"],
    [/error: redefinition of ['‘]([^'’]+)['’]/i, "エラー: '$1' が重複して定義されています。"],
    [/error: invalid conversion from ['‘]([^'’]+)['’] to ['‘]([^'’]+)['’]/i, "エラー: '$1' から '$2' へ変換できません。型を確認してください。"],
    [/error: lvalue required as left operand of assignment/i, 'エラー: 代入演算子の左側には変更可能な変数が必要です。'],
    [/error: a function-definition is not allowed here before/i, 'エラー: 関数の中に別の関数定義が入っています。直前の波括弧 { } を確認してください。'],
    [/error: expected declaration before ['‘]}['’] token/i, "エラー: '}' の位置が不正です。波括弧の対応を確認してください。"],
    [/exit status 1/i, 'コンパイルに失敗しました。'],
    [/\berror:/i, 'エラー:'],
    [/\bwarning:/i, '警告:'],
    [/\bnote:/i, '補足:'],
  ];
  for (const [pattern, replacement] of replacements) text = text.replace(pattern, replacement);
  return text;
}

function localizeCompilerOutput(output: string) {
  return output.split(/\r?\n/).map(localizeCompilerLine).join('\n');
}

const emptySnapshot: MegaSnapshot = {
  cycles: 0,
  simMs: 0,
  pc: 0,
  porta: 0,
  ddra: 0,
  d11: 'INPUT',
  d12: 'INPUT',
  pwm11: 0,
  pwm12: 0,
  pwm44: 0,
  pwm45: 0,
  pwm46: 0,
  out11: 0,
  out12: 0,
  out44: 0,
  out45: 0,
  out46: 0,
  dcmRps: 0,
  dcmAngle: 30,
  dcmMode: 'coast',
  dcmDirection: 0,
  dcmCommandSpeed: 0,
  phoHigh: false,
  phoDropped: 0,
  stpmAngle: 0,
  stpmMissed: 0,
  segBytes: [0, 0, 0],
  buzzerHz: 0,
};

function AvrWorkbench({ source, circuitVoltages, inputVoltageProvider, onSnapshot, onOpenHardware, onStatusChange, onBuiltSource, onSerialOutput, onStepperStep, buildRequest = 0, stopRequest = 0, showControls = true, compact = false }: Props) {
  const runnerRef = useRef<MegaRunner | null>(null);
  const circuitVoltagesRef = useRef(circuitVoltages);
  const inputVoltageProviderRef = useRef(inputVoltageProvider);
  const inputRefreshTimerRef = useRef<number | null>(null);
  const runTokenRef = useRef(0);
  const lastBuildRequestRef = useRef(buildRequest);
  const lastStopRequestRef = useRef(stopRequest);
  const serialBufferRef = useRef('');
  const serialFlushTimerRef = useRef<number | null>(null);
  const [status, setStatus] = useState<WorkbenchStatus>('idle');
  const [snapshot, setSnapshot] = useState<MegaSnapshot>(emptySnapshot);
  const [compilerOutput, setCompilerOutput] = useState('');
  const [serialOutput, setSerialOutput] = useState('');
  const [firmwareBytes, setFirmwareBytes] = useState(0);
  const [detailsOpen, setDetailsOpen] = useState(false);

  useEffect(() => {
    onStatusChange?.(status);
  }, [status, onStatusChange]);

  const clearInputRefresh = () => {
    if (inputRefreshTimerRef.current !== null) window.clearInterval(inputRefreshTimerRef.current);
    inputRefreshTimerRef.current = null;
  };

  useEffect(() => {
    circuitVoltagesRef.current = circuitVoltages;
    runnerRef.current?.syncInputs(inputVoltageProviderRef.current?.() ?? circuitVoltages);
  }, [circuitVoltages]);

  useEffect(() => {
    inputVoltageProviderRef.current = inputVoltageProvider;
    runnerRef.current?.syncInputs(inputVoltageProvider?.() ?? circuitVoltagesRef.current);
  }, [inputVoltageProvider]);

  useEffect(
    () => () => {
      runTokenRef.current += 1;
      runnerRef.current?.stop();
      clearInputRefresh();
      if (serialFlushTimerRef.current) window.clearTimeout(serialFlushTimerRef.current);
      serialFlushTimerRef.current = null;
      serialBufferRef.current = '';
      onSnapshot?.(null);
    },
    [onSnapshot]
  );

  const publish = (next: MegaSnapshot) => {
    if (!compact) setSnapshot(next);
    onSnapshot?.(next);
  };

  const stop = () => {
    runTokenRef.current += 1;
    runnerRef.current?.stop();
    clearInputRefresh();
    runnerRef.current = null;
    onSnapshot?.(null);
    setStatus('stopped');
  };

  const buildAndRun = async () => {
    const token = runTokenRef.current + 1;
    runTokenRef.current = token;
    runnerRef.current?.stop();
    clearInputRefresh();
    runnerRef.current = null;
    onSnapshot?.(null);
    setStatus('compiling');
    setCompilerOutput('Mega向けにコンパイル中…');
    if (serialFlushTimerRef.current) window.clearTimeout(serialFlushTimerRef.current);
    serialFlushTimerRef.current = null;
    serialBufferRef.current = '';
    setSerialOutput('');
    onSerialOutput?.('');
    setSnapshot(emptySnapshot);
    setFirmwareBytes(0);
    try {
      const result = await buildMegaHex(source);
      if (runTokenRef.current !== token) return;
      const rawOutput = [result.stdout, result.stderr].filter(Boolean).join('\n').trim();
      const output = localizeCompilerOutput(rawOutput);
      setCompilerOutput(output || 'コンパイル完了');
      if (!result.hex) {
        setStatus('error');
        setCompilerOutput(output || 'HEXが生成されませんでした。コンパイル内容を確認してください。');
        return;
      }
      const dataBytes = result.hex
        .split(/\r?\n/)
        .filter(line => line.startsWith(':') && line.slice(7, 9) === '00')
        .reduce((sum, line) => sum + Number.parseInt(line.slice(1, 3), 16), 0);
      setFirmwareBytes(dataBytes);
      const runner = new MegaRunner(result.hex);
      runnerRef.current = runner;
      runner.syncInputs(inputVoltageProviderRef.current?.() ?? circuitVoltagesRef.current);
      runner.onStepperStep = simMs => onStepperStep?.(simMs);
      runner.onSerialByte = value => {
        serialBufferRef.current = (serialBufferRef.current + String.fromCharCode(value)).slice(-12000);
        if (serialFlushTimerRef.current) return;
        serialFlushTimerRef.current = window.setTimeout(() => {
          const buffered = serialBufferRef.current;
          serialBufferRef.current = '';
          serialFlushTimerRef.current = null;
          if (buffered) setSerialOutput(text => {
            const next = (text + buffered).slice(-6000);
            onSerialOutput?.(next);
            return next;
          });
        }, 100);
      };
      onBuiltSource?.(source);
      setStatus('running');
      runner.start(publish);
      clearInputRefresh();
      inputRefreshTimerRef.current = window.setInterval(() => {
        const active = runnerRef.current;
        if (!active) return;
        active.syncInputs(inputVoltageProviderRef.current?.() ?? circuitVoltagesRef.current);
      }, 8);
    } catch (error) {
      if (runTokenRef.current !== token) return;
      setStatus('error');
      onSnapshot?.(null);
      setCompilerOutput(
        error instanceof Error
          ? `実コンパイル/実行を開始できませんでした: ${error.message}`
          : '実コンパイル/実行を開始できませんでした。'
      );
    }
  };

  useEffect(() => {
    if (buildRequest === lastBuildRequestRef.current) return;
    lastBuildRequestRef.current = buildRequest;
    void buildAndRun();
  }, [buildRequest]);

  useEffect(() => {
    if (stopRequest === lastStopRequestRef.current) return;
    lastStopRequestRef.current = stopRequest;
    stop();
  }, [stopRequest]);

  const statusText =
    status === 'idle'
      ? '未実行'
      : status === 'compiling'
        ? 'COMPILING'
        : status === 'running'
          ? 'RUNNING'
          : status === 'stopped'
            ? 'STOPPED'
            : 'ERROR';

  const conciseError =
    compilerOutput
      .split(/\r?\n/)
      .find(line => /\berror:/i.test(line)) ||
    compilerOutput.split(/\r?\n/).find(Boolean) ||
    'コンパイルに失敗しました。';

  if (compact) {
    return (
      <section className="build-panel shrink-0 rounded-xl border border-[#bfd0db] bg-[#eef5f9] p-2 text-[#354957]">
        <div className="flex flex-wrap items-center gap-2">
          <span className={`build-status rounded-lg px-2 py-1 text-[10px] font-black ${status === 'running' ? 'is-running' : status === 'compiling' ? 'is-compiling' : status === 'error' ? 'is-error' : ''}`}>{statusText}</span>
          {showControls && <button type="button" onClick={() => void buildAndRun()} disabled={status === 'compiling'} className="min-h-10 flex-1 rounded-lg bg-[#5e8fb2] px-3 text-xs font-black text-white disabled:opacity-50"><Play size={14} className="mr-1 inline" />{status === 'compiling' ? 'コンパイル中…' : status === 'running' ? '再ビルド＆実行' : 'ビルド＆実行'}</button>}
          {showControls && <button type="button" onClick={stop} disabled={status !== 'running' && status !== 'compiling'} className="min-h-10 rounded-lg border border-[#ccd6dc] bg-white px-3 text-xs text-[#566a78] disabled:opacity-35"><Square size={14} className="mr-1 inline" />停止</button>}
          <button type="button" onClick={() => setDetailsOpen(value => !value)} className="build-log-button min-h-10 rounded-lg border border-[#c9d6df] bg-white/75 px-3 text-xs font-bold text-[#536c7b]">{detailsOpen ? 'ログを閉じる' : 'ログ'}</button>
          {onOpenHardware && <button type="button" onClick={onOpenHardware} className="hidden min-h-10 rounded-lg border border-[#a8c7d9] bg-white/65 px-3 text-xs font-bold text-[#3d7398] sm:block"><Gauge size={14} className="mr-1 inline" />出力詳細</button>}
        </div>
        {status === 'error' && <div className="build-error mono mt-2 rounded-lg border border-[#e3b9b5] bg-[#fff0ee] px-2.5 py-2 text-[10px] font-semibold leading-4 text-[#93433f]">{conciseError}</div>}
        {detailsOpen && (
          <div className="mt-2 grid gap-2 md:grid-cols-2">
            <div className="build-log-card rounded-lg border border-[#d8dfe3] bg-white/75 p-2"><div className="text-[10px] font-black text-[#657580]">Compiler</div><pre className="mono mt-1 max-h-28 overflow-auto whitespace-pre-wrap text-[10px] leading-4 text-[#687782]">{compilerOutput || 'ビルドすると出力を表示します。'}</pre></div>
            <div className="build-log-card rounded-lg border border-[#d8dfe3] bg-white/75 p-2"><div className="text-[10px] font-black text-[#657580]">Serial</div><pre className="mono mt-1 max-h-28 overflow-auto whitespace-pre-wrap text-[10px] leading-4 text-[#477865]">{serialOutput || 'Serial出力待ち'}</pre></div>
          </div>
        )}
      </section>
    );
  }

  return (
    <section className="rounded-2xl border border-emerald-400/15 bg-emerald-400/[0.035] p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Cpu size={18} className="text-emerald-300" />
            <h2 className="font-semibold">Mega 2560 実行</h2>
          </div>
          <p className="mt-1 max-w-2xl text-sm text-slate-400">
            編集した.cppをMega向けHEXへ実コンパイルし、そのまま仮想AVRで実行します。
          </p>
        </div>
        <span
          className={`rounded-full px-3 py-1 text-xs font-semibold ${
            status === 'running'
              ? 'bg-emerald-400/15 text-emerald-200'
              : status === 'compiling'
                ? 'bg-sky-400/15 text-sky-200'
                : status === 'error'
                  ? 'bg-red-400/15 text-red-200'
                  : 'bg-white/5 text-slate-300'
          }`}
        >
          {statusText}
        </span>
      </div>

      <div className="mt-4 grid gap-2 sm:grid-cols-3">
        <button
          type="button"
          onClick={() => void buildAndRun()}
          disabled={status === 'compiling'}
          className="min-h-12 rounded-xl bg-emerald-400 px-3 text-sm font-bold text-slate-950 disabled:opacity-50"
        >
          <Play size={16} className="mr-1 inline" />
          {status === 'compiling' ? 'コンパイル中…' : status === 'running' ? '再ビルド＆実行' : 'Megaビルド＆実行'}
        </button>
        <button
          type="button"
          onClick={stop}
          disabled={status !== 'running' && status !== 'compiling'}
          className="min-h-12 rounded-xl border border-white/10 px-3 text-sm text-slate-200 disabled:opacity-40"
        >
          <Square size={15} className="mr-1 inline" /> 停止
        </button>
        <button
          type="button"
          onClick={onOpenHardware}
          disabled={!onOpenHardware || status !== 'running'}
          className="min-h-12 rounded-xl border border-cyan-400/20 bg-cyan-400/5 px-3 text-sm font-semibold text-cyan-100 disabled:opacity-35"
        >
          <Gauge size={16} className="mr-1 inline" /> 実機を見る
        </button>
      </div>

      {status === 'running' && (
        <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 rounded-xl border border-emerald-400/15 bg-emerald-400/5 px-3 py-2 text-xs text-emerald-100">
          <span>Sim {snapshot.simMs.toFixed(1)} ms</span>
          <span>PORTA {snapshot.porta.toString(2).padStart(8, '0')}</span>
          <span>DCM {snapshot.dcmRps.toFixed(2)} rps</span>
          <span>ブザー {Math.round(snapshot.buzzerHz)} Hz</span>
        </div>
      )}

      {status === 'error' && (
        <div className="mt-3 rounded-xl border border-red-400/25 bg-red-400/10 px-3 py-3">
          <div className="text-xs font-bold text-red-200">コンパイル/実行エラー</div>
          <div className="mono mt-1 break-words text-xs leading-5 text-red-100">{conciseError}</div>
          <button
            type="button"
            onClick={() => setDetailsOpen(true)}
            className="mt-2 min-h-9 rounded-lg border border-red-300/20 px-3 text-xs font-semibold text-red-100"
          >
            コンパイラ全文を見る
          </button>
        </div>
      )}

      <button
        type="button"
        onClick={() => setDetailsOpen(value => !value)}
        className="mt-3 flex min-h-11 w-full items-center justify-between rounded-xl border border-white/10 bg-black/15 px-3 text-sm text-slate-300"
      >
        <span>詳細デバッグ情報</span>
        {detailsOpen ? <ChevronUp size={17} /> : <ChevronDown size={17} />}
      </button>

      {detailsOpen && (
        <div className="mt-3 space-y-3">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <RuntimeCard label="Sim time" value={`${snapshot.simMs.toFixed(1)} ms`} />
            <RuntimeCard label="PC" value={`0x${snapshot.pc.toString(16).padStart(4, '0')}`} />
            <RuntimeCard label="Firmware" value={firmwareBytes ? `${firmwareBytes} B` : '--'} />
            <RuntimeCard label="PORTA" value={snapshot.porta.toString(2).padStart(8, '0')} />
            <RuntimeCard label="D11" value={`${snapshot.d11} / OUT ${snapshot.out11}`} />
            <RuntimeCard label="D12" value={`${snapshot.d12} / OUT ${snapshot.out12}`} />
            <RuntimeCard label="D44/45" value={`${snapshot.out44} / ${snapshot.out45}`} />
            <RuntimeCard label="D46" value={`${snapshot.out46}`} />
          </div>

          <div className="rounded-xl border border-cyan-400/15 bg-cyan-400/5 p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="text-sm font-semibold text-cyan-100">入力回路状態 → Mega入力</div>
                <div className="mt-1 text-xs leading-5 text-slate-400">
                  digitalRead / analogReadが読むAVR入力へ同期している値です。
                </div>
              </div>
              <span
                className={`rounded-full px-2 py-1 text-[10px] font-semibold ${
                  status === 'running'
                    ? 'bg-emerald-400/15 text-emerald-200'
                    : 'bg-white/5 text-slate-400'
                }`}
              >
                {status === 'running' ? 'AVRへ同期中' : '次回実行時に同期'}
              </span>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {inputDigitalTargets.map(target => {
                const voltage = circuitVoltages[target];
                return (
                  <RuntimeCard
                    key={target}
                    label={target}
                    value={
                      typeof voltage === 'number'
                        ? `${digitalLabel(voltage)} · ${voltage.toFixed(2)} V`
                        : '--'
                    }
                  />
                );
              })}
              {inputAnalogTargets.map(target => {
                const voltage = circuitVoltages[target];
                const raw = analogValue(voltage);
                return (
                  <RuntimeCard
                    key={target}
                    label={target}
                    value={raw === null ? '--' : `${raw} · ${voltage?.toFixed(2) ?? '--'} V`}
                  />
                );
              })}
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            <div className="rounded-xl bg-black/25 p-3">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-200">
                <TerminalSquare size={16} /> Compiler
              </div>
              <pre className="mono mt-2 max-h-44 overflow-auto whitespace-pre-wrap text-xs leading-5 text-slate-400">
                {compilerOutput || 'ビルドすると実コンパイラの出力を表示します。'}
              </pre>
            </div>
            <div className="rounded-xl bg-black/25 p-3">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-200">
                <TerminalSquare size={16} /> Serial
              </div>
              <pre className="mono mt-2 max-h-44 overflow-auto whitespace-pre-wrap text-xs leading-5 text-emerald-200">
                {serialOutput || 'Serial出力待ち'}
              </pre>
            </div>
          </div>
        </div>
      )}

      <div className="mt-3 rounded-xl border border-sky-400/15 bg-sky-400/5 p-3 text-xs leading-5 text-slate-400">
        実行中に画面を切り替えても停止しません。仮想入力の変更も実行中のMegaへ同期され、スマホでは画面下から再ビルド・停止・実機確認ができます。
      </div>

      <div
        className="fixed inset-x-2 z-50 grid grid-cols-[1fr_auto_auto] gap-2 rounded-2xl border border-emerald-400/20 bg-[#0d1412]/95 p-2 shadow-2xl shadow-black/50 backdrop-blur sm:hidden"
        style={{ bottom: 'max(0.5rem, env(safe-area-inset-bottom))' }}
      >
        <button
          type="button"
          onClick={() => void buildAndRun()}
          disabled={status === 'compiling'}
          className="min-h-12 min-w-0 rounded-xl bg-emerald-400 px-3 text-xs font-bold text-slate-950 disabled:opacity-50"
        >
          <Play size={15} className="mr-1 inline" />
          {status === 'compiling' ? 'COMPILING' : status === 'running' ? '再実行' : 'ビルド＆実行'}
        </button>
        <button
          type="button"
          onClick={onOpenHardware}
          disabled={!onOpenHardware || status !== 'running'}
          className="min-h-12 min-w-12 rounded-xl border border-cyan-400/20 bg-cyan-400/5 px-2 text-cyan-100 disabled:opacity-30"
          aria-label="実機を見る"
        >
          <Gauge size={18} className="mx-auto" />
        </button>
        <button
          type="button"
          onClick={stop}
          disabled={status !== 'running' && status !== 'compiling'}
          className="min-h-12 min-w-12 rounded-xl border border-white/10 px-2 text-slate-200 disabled:opacity-30"
          aria-label="停止"
        >
          <Square size={17} className="mx-auto" />
        </button>
      </div>
    </section>
  );
}

function RuntimeCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0 rounded-xl bg-black/25 p-3">
      <div className="text-[11px] text-slate-500">{label}</div>
      <div className="mt-1 break-words text-sm font-bold text-slate-100">{value}</div>
    </div>
  );
}

export default AvrWorkbench;
