import { useEffect, useRef, useState } from 'react';
import { Volume2 } from 'lucide-react';
import { segmentText } from './SevenSegmentDigit';
import type { MegaSnapshot } from './avrMega';

type OutputKey = 'dcm' | 'stpm' | 'seg' | 'cled' | 'buzzer';

type Props = {
  snapshot: MegaSnapshot | null;
  attentionToken?: number;
  attentionBaseline?: MegaSnapshot | null;
};

const outputChanged = (key: OutputKey, before: MegaSnapshot, after: MegaSnapshot) => {
  if (key === 'dcm') return before.dcmDirection !== after.dcmDirection || Math.abs(before.dcmRps - after.dcmRps) > 0.05 || Math.abs(before.dcmAngle - after.dcmAngle) > 1;
  if (key === 'stpm') return Math.abs(before.stpmAngle - after.stpmAngle) > 0.5 || before.porta !== after.porta;
  if (key === 'seg') return before.segBytes.some((value, index) => value !== after.segBytes[index]);
  if (key === 'cled') return Math.abs(before.out44 - after.out44) > 2 || Math.abs(before.out45 - after.out45) > 2 || Math.abs(before.out46 - after.out46) > 2;
  return Math.abs(before.buzzerHz - after.buzzerHz) > 2;
};

const clockPosition = (angle: number) => {
  const value = Math.round((((angle % 360) + 360) % 360) / 30) % 12;
  return value === 0 ? 12 : value;
};

function useContinuousAngle(angle: number) {
  const previousRef = useRef(angle);
  const visualRef = useRef(angle);
  const [visualAngle, setVisualAngle] = useState(angle);

  useEffect(() => {
    const previous = previousRef.current;
    const delta = ((angle - previous + 540) % 360) - 180;
    visualRef.current += delta;
    previousRef.current = angle;
    setVisualAngle(visualRef.current);
  }, [angle]);

  return visualAngle;
}

function DcmMechanism({ snapshot }: { snapshot: MegaSnapshot }) {
  const visualAngle = useContinuousAngle(snapshot.dcmAngle);
  const direction = snapshot.dcmDirection === 1 ? 'CW ↻' : snapshot.dcmDirection === -1 ? 'CCW ↺' : 'STOP';

  return (
    <div className="dcm-card instrument-card rounded-lg border p-1.5">
      <div className="flex items-center justify-between gap-1">
        <div>
          <div className="instrument-kicker">DCM + PHO</div>
          <div className="text-[10px] font-black text-[#2f4149]">{direction} · {snapshot.dcmRps.toFixed(2)} rps</div>
        </div>
        <span className={`logic-badge ${snapshot.phoHigh ? 'is-high' : 'is-low'}`}><span className="logic-led" />PHO {snapshot.phoHigh ? '透過' : '遮断'}</span>
      </div>
      <div className="dcm-mechanism-visual relative mx-auto mt-1 h-[88px] w-[124px]">
        <div className="absolute bottom-[21px] left-[5px] h-[36px] w-[52px] rounded-l-[18px] rounded-r-md border border-[#6c7475] bg-gradient-to-b from-[#d8dcda] via-[#929c9e] to-[#6c777b] shadow-[inset_0_2px_2px_rgba(255,255,255,.55),0_4px_7px_rgba(27,40,46,.18)]">
          <div className="absolute left-2 top-2 h-1.5 w-8 rounded-full bg-white/30" />
          <div className="absolute right-[-7px] top-1/2 h-2 w-8 -translate-y-1/2 rounded-full border border-[#817762] bg-gradient-to-b from-[#e3d5b8] to-[#a68c62]" />
        </div>
        <div className="absolute left-[47px] top-1/2 h-[72px] w-[72px] -translate-y-1/2 rounded-full border-2 border-[#82745d] bg-gradient-to-br from-[#d6dde0] via-[#8fa1a8] to-[#526975] shadow-[inset_0_0_10px_rgba(29,45,53,.32),0_4px_8px_rgba(29,45,53,.2)]" style={{ transform: `translateY(-50%) rotate(${visualAngle}deg)`, transition: 'transform 35ms linear' }}>
          {Array.from({ length: 6 }, (_value, index) => <div key={index} className="absolute inset-0" style={{ transform: `rotate(${index * 60}deg)` }}><div className="absolute right-1 top-1/2 h-2.5 w-4 -translate-y-1/2 rounded-full border border-[#314750]/45 bg-[#263f4a] shadow-inner" /></div>)}
          <div className="absolute left-1/2 top-1 h-2.5 w-2.5 -translate-x-1/2 rounded-full border-2 border-[#ffe2dc] bg-[#d95c57] shadow-[0_0_8px_rgba(217,92,87,.65)]" />
          <div className="device-metal absolute left-1/2 top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#6f7776] shadow-sm" />
        </div>
        <div className="absolute right-0 top-1/2 -translate-y-1/2">
          <div className={`absolute -top-6 right-0 h-4 w-7 rounded-t border-x border-t ${snapshot.phoHigh ? 'border-[#4f9c88] bg-[#d8eee7]' : 'border-[#8b9697] bg-[#e7e9e5]'}`} />
          <div className={`absolute right-0 top-2 h-4 w-7 rounded-b border-x border-b ${snapshot.phoHigh ? 'border-[#4f9c88] bg-[#d8eee7]' : 'border-[#8b9697] bg-[#e7e9e5]'}`} />
          <div className={`absolute right-0 top-0 h-[2px] w-7 ${snapshot.phoHigh ? 'bg-[#58d3c2] shadow-[0_0_7px_rgba(88,211,194,.7)]' : 'bg-[#a26c65]'}`} />
        </div>
      </div>
      <div className="px-0.5 text-center text-[7px] font-semibold leading-tight text-[#72766f]">赤印=回転確認 · 穴通過→PHO HIGH</div>
    </div>
  );
}

function StepperMechanism({ snapshot }: { snapshot: MegaSnapshot }) {
  const visualAngle = useContinuousAngle(snapshot.stpmAngle);
  const current = clockPosition(snapshot.stpmAngle);
  const diameter = 100;
  const radius = 39;

  return (
    <div className="stpm-card instrument-card rounded-lg border p-1.5">
      <div className="flex items-center justify-between gap-1">
        <div><div className="instrument-kicker">STEPPING MOTOR</div><div className="text-[10px] font-black text-[#2f4149]">{current}時方向 · {snapshot.stpmAngle.toFixed(0)}°</div></div>
        <span className="device-pin-badge mono">{snapshot.porta.toString(2).padStart(8, '0')}</span>
      </div>
      <div className="mx-auto mt-1 flex items-center justify-center">
        <div className="stpm-dial relative rounded-full border-2 border-[#9c8766] bg-[#ded2bc] shadow-[inset_0_0_10px_rgba(86,67,42,.16),0_4px_8px_rgba(48,56,55,.10)]" style={{ width: diameter, height: diameter }}>
          <div className="absolute inset-[8px] rounded-full border border-[#60737d] bg-gradient-to-br from-[#29424f] via-[#536b75] to-[#1f3540] shadow-inner" />
          {Array.from({ length: 12 }, (_value, index) => {
            const label = index === 0 ? 12 : index;
            const degrees = index * 30;
            const active = label === current;
            return <span key={label} className={`absolute left-1/2 top-1/2 z-10 flex h-4 w-4 items-center justify-center rounded-full text-[7px] font-black ${active ? 'bg-[#22b9c2] text-white shadow-[0_0_7px_rgba(34,185,194,.65)]' : 'text-[#d7dedb]'}`} style={{ transform: `translate(-50%, -50%) rotate(${degrees}deg) translateY(-${radius}px) rotate(${-degrees}deg)` }}>{label}</span>;
          })}
          <div className="absolute left-1/2 top-1/2 z-10 h-[34%] w-[2px] origin-bottom -translate-x-1/2 -translate-y-full rounded-full bg-[#61d9da] shadow-[0_0_7px_rgba(97,217,218,.6)]" style={{ transform: `translate(-50%, -100%) rotate(${visualAngle}deg)`, transformOrigin: '50% 100%', transition: 'transform 28ms linear' }} />
          <div className="device-metal absolute left-1/2 top-1/2 z-20 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#5f6b6d] shadow-sm" />
        </div>
      </div>
      <div className="mt-1 px-0.5 text-center text-[7px] font-semibold leading-tight text-[#72766f]">1 step = 3° · PORTA 1→2→4→8</div>
    </div>
  );
}

function MiniSevenSegment({ value }: { value: number }) {
  const active = (bit: number) => (value & (1 << bit)) !== 0;
  const fill = (bit: number) => active(bit) ? '#ef5a61' : '#321f25';
  return (
    <svg viewBox="0 0 52 78" className="mini-seven-seg h-12 w-8" aria-label={`7セグ ${segmentText(value)}`}>
      <polygon points="13,5 39,5 44,9 39,13 13,13 8,9" fill={fill(0)} />
      <polygon points="40,12 45,17 45,35 40,40 35,35 35,17" fill={fill(1)} />
      <polygon points="40,39 45,44 45,62 40,67 35,62 35,44" fill={fill(2)} />
      <polygon points="13,65 39,65 44,69 39,73 13,73 8,69" fill={fill(3)} />
      <polygon points="12,39 17,44 17,62 12,67 7,62 7,44" fill={fill(4)} />
      <polygon points="12,12 17,17 17,35 12,40 7,35 7,17" fill={fill(5)} />
      <polygon points="13,35 39,35 44,39 39,43 13,43 8,39" fill={fill(6)} />
      <circle cx="48" cy="69" r="2.6" fill={fill(7)} />
    </svg>
  );
}

function LiveOutputPanel({ snapshot, attentionToken = 0, attentionBaseline = null }: Props) {
  const snapshotRef = useRef(snapshot);
  const sampleTimerRef = useRef<number | null>(null);
  const clearTimerRef = useRef<number | null>(null);
  const [flash, setFlash] = useState<Set<OutputKey>>(new Set());

  useEffect(() => { snapshotRef.current = snapshot; }, [snapshot]);
  useEffect(() => {
    if (!attentionToken || !attentionBaseline) return;
    if (sampleTimerRef.current) window.clearTimeout(sampleTimerRef.current);
    if (clearTimerRef.current) window.clearTimeout(clearTimerRef.current);
    sampleTimerRef.current = window.setTimeout(() => {
      const current = snapshotRef.current;
      if (!current) return;
      const keys: OutputKey[] = ['dcm', 'stpm', 'seg', 'cled', 'buzzer'];
      setFlash(new Set(keys.filter(key => outputChanged(key, attentionBaseline, current))));
      clearTimerRef.current = window.setTimeout(() => setFlash(new Set()), 900);
    }, 220);
    return () => { if (sampleTimerRef.current) window.clearTimeout(sampleTimerRef.current); };
  }, [attentionBaseline, attentionToken]);
  useEffect(() => () => {
    if (sampleTimerRef.current) window.clearTimeout(sampleTimerRef.current);
    if (clearTimerRef.current) window.clearTimeout(clearTimerRef.current);
  }, []);

  const wrapper = (key: OutputKey) => flash.has(key) ? 'ring-2 ring-[#6f9fbe] rounded-lg bg-[#dcebf5]/80' : '';

  if (!snapshot) {
    return <section className="io-panel output-panel flex h-full items-center justify-center rounded-xl border border-[#d8c7ad] bg-[#faf3e7] p-2 text-center text-[9px] font-semibold leading-4 text-[#8b8176]">RUNすると、全制御対象をここで同時に観察できます。</section>;
  }

  const rgb = [snapshot.out44, snapshot.out45, snapshot.out46];
  const seg = snapshot.segBytes.map(segmentText).join(' ');

  return (
    <section className="io-panel output-panel flex h-full min-h-0 min-w-0 flex-col overflow-x-hidden overflow-y-auto rounded-xl border border-[#d8c7ad] bg-[#faf3e7] p-1.5 shadow-[0_8px_22px_rgba(108,89,65,0.05)] sm:p-2">
      <div className="output-panel-head flex min-h-8 min-w-0 shrink-0 items-center justify-between gap-1"><div className="min-w-0 text-[8px] font-black tracking-[0.08em] text-[#765d43] sm:text-[10px]">CONTROLLED OUTPUT</div><div className="shrink-0 text-[7px] font-black text-[#9a8c7b]">LIVE</div></div>
      <div className="output-grid grid min-h-0 flex-1 content-start gap-1">
        <div className={wrapper('dcm')}><DcmMechanism snapshot={snapshot} /></div>
        <div className={wrapper('stpm')}><StepperMechanism snapshot={snapshot} /></div>
        <div className={`${wrapper('seg')} seg-card instrument-card rounded-lg border px-1.5 py-1`}>
          <div className="flex items-center justify-between"><span className="instrument-kicker">7SEG</span><span className="text-[7px] font-semibold text-[#7d7365]">L / M / R</span></div>
          <div className="mx-auto mt-0.5 flex w-fit items-center gap-1 rounded-md border border-[#44323a] bg-[#17171a] px-2 py-1 shadow-[inset_0_0_9px_rgba(0,0,0,.65)]">
            {snapshot.segBytes.map((value, index) => <MiniSevenSegment key={index} value={value} />)}
          </div>
          <div className="mono mt-0.5 truncate text-center text-[7px] font-black tracking-[0.12em] text-[#a95056]">{seg}</div>
        </div>
        <div className="output-mini-strip grid grid-cols-2 gap-1">
          <div className={`${wrapper('cled')} cled-card instrument-card rounded-lg border p-1.5`}>
            <div className="instrument-kicker">CLED</div>
            <div className="mt-0.5 flex items-center gap-2">
              <div className="relative h-8 w-8 shrink-0">
                <div className="absolute bottom-0 left-1/2 h-2 w-5 -translate-x-1/2 rounded-b border border-[#8a8172] bg-[#b7ad9b]" />
                <div className="absolute left-1/2 top-0 h-7 w-6 -translate-x-1/2 rounded-t-full rounded-b-md border border-white/70 shadow-[inset_0_2px_5px_rgba(255,255,255,.75),0_0_8px_rgba(0,0,0,.08)]" style={{ background: `radial-gradient(circle at 35% 25%, rgba(255,255,255,.9), rgba(${rgb[0]},${rgb[1]},${rgb[2]},.95) 45%, rgba(${rgb[0]},${rgb[1]},${rgb[2]},.45))`, boxShadow: `0 0 10px rgba(${rgb[0]},${rgb[1]},${rgb[2]},.45)` }} />
              </div>
              <div className="min-w-0 flex-1"><div className="mono text-[7px] font-black text-[#41545a]">R {rgb[0]}</div><div className="mono text-[7px] font-black text-[#41545a]">G {rgb[1]}</div><div className="mono text-[7px] font-black text-[#41545a]">B {rgb[2]}</div></div>
            </div>
          </div>
          <div className={`${wrapper('buzzer')} buzzer-card instrument-card min-w-0 rounded-lg border p-1.5`}>
            <div className="flex items-center gap-1 instrument-kicker"><Volume2 size={9} />SPK</div>
            <div className="mt-0.5 flex items-center gap-2">
              <div className="relative h-9 w-9 shrink-0 rounded-full border border-[#716955] bg-[#c7bda9] p-1 shadow-inner">
                <div className="absolute inset-[5px] rounded-full border border-[#52616a] bg-[#233842] shadow-[inset_0_0_7px_rgba(0,0,0,.55)]" />
                <div className="absolute inset-[10px] rounded-full bg-[#4b606a]" />
                {snapshot.buzzerHz > 1 && <><span className="speaker-wave absolute -right-1 top-2 h-5 w-2 rounded-r-full border-r border-[#22b9c2]" /><span className="speaker-wave speaker-wave-delay absolute -right-2 top-1 h-7 w-3 rounded-r-full border-r border-[#22b9c2]" /></>}
              </div>
              <div className="min-w-0"><div className="text-[10px] font-black text-[#2f4149]">{snapshot.buzzerHz > 1 ? `${snapshot.buzzerHz.toFixed(0)} Hz` : '無音'}</div><div className="text-[6px] font-semibold leading-tight text-[#7c756b]">端末音声は上部で切替</div></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default LiveOutputPanel;
