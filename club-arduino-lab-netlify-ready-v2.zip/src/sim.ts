export type ArduinoTarget =
  | '5V'
  | 'GND'
  | 'NC'
  | 'D1'
  | 'D3'
  | 'D5'
  | 'D7'
  | 'D9'
  | 'D20'
  | 'D21'
  | 'A2'
  | 'A4'
  | 'A6'
  | 'A8'
  | 'A10';

export type ComponentKind = 'TC' | 'TG' | 'PH' | 'PR' | 'VR' | 'JOY' | 'ENC';

export type Component = {
  id: string;
  kind: ComponentKind;
};

export type Wire = {
  id: string;
  a: string;
  b: string;
};

export type Resistor = {
  id: string;
  value: number;
  a: string;
  b: string;
};

export type InputState = {
  tcPressed: boolean;
  tgHigh: boolean;
  phTransparent: boolean;
  prLevel: number;
  vr: number;
  joyX: number;
  joyY: number;
  encoderPulse: number;
  encoderPhase: number;
};

export type SolveResult = {
  endpointVoltage: Record<string, number | null>;
  arduinoVoltage: Partial<Record<ArduinoTarget, number | null>>;
  shorted: boolean;
  floatingTargets: ArduinoTarget[];
};

export const componentNames: Record<ComponentKind, string> = {
  TC: 'タクトスイッチ',
  TG: 'トグルスイッチ',
  PH: 'フォトインタラプタ',
  PR: 'フォトリフレクタ',
  VR: '半固定ボリューム',
  JOY: 'ジョイスティック',
  ENC: 'ロータリーエンコーダ',
};

export function componentEndpoints(
  component: Component
): Array<{ id: string; label: string }> {
  const p = `${component.id}.`;
  if (component.kind === 'TC')
    return [
      { id: `${p}A`, label: 'A' },
      { id: `${p}B`, label: 'B' },
    ];
  if (component.kind === 'TG')
    return [
      { id: `${p}COM`, label: 'COM' },
      { id: `${p}UP`, label: 'UP' },
      { id: `${p}DOWN`, label: 'DOWN' },
    ];
  if (component.kind === 'PH' || component.kind === 'PR')
    return [
      { id: `${p}A`, label: 'Anode' },
      { id: `${p}K`, label: 'Cathode' },
      { id: `${p}C`, label: 'Collector' },
      { id: `${p}E`, label: 'Emitter' },
    ];
  if (component.kind === 'VR')
    return [
      { id: `${p}A`, label: 'A' },
      { id: `${p}W`, label: 'Wiper' },
      { id: `${p}B`, label: 'B' },
    ];
  if (component.kind === 'JOY')
    return [
      { id: `${p}XA`, label: 'X-A' },
      { id: `${p}XW`, label: 'X-W' },
      { id: `${p}XB`, label: 'X-B' },
      { id: `${p}YA`, label: 'Y-A' },
      { id: `${p}YW`, label: 'Y-W' },
      { id: `${p}YB`, label: 'Y-B' },
    ];
  return [
    { id: `${p}COM`, label: 'COM' },
    { id: `${p}A`, label: 'A' },
    { id: `${p}B`, label: 'B' },
  ];
}

class UnionFind {
  private parent = new Map<string, string>();
  add(x: string) {
    if (!this.parent.has(x)) this.parent.set(x, x);
  }
  find(x: string): string {
    this.add(x);
    const p = this.parent.get(x)!;
    if (p === x) return x;
    const root = this.find(p);
    this.parent.set(x, root);
    return root;
  }
  union(a: string, b: string) {
    const ra = this.find(a);
    const rb = this.find(b);
    if (ra !== rb) this.parent.set(rb, ra);
  }
}

type Edge = { a: string; b: string; r: number };

function potEdges(prefix: string, position: number): Edge[] {
  const p = Math.max(0.001, Math.min(0.999, position));
  const total = 10000;
  return [
    { a: `${prefix}A`, b: `${prefix}W`, r: total * p },
    { a: `${prefix}W`, b: `${prefix}B`, r: total * (1 - p) },
  ];
}

export function solveCircuit(
  components: Component[],
  wires: Wire[],
  resistors: Resistor[],
  mapping: Record<number, ArduinoTarget>,
  state: InputState,
  floatNoise: number
): SolveResult {
  const uf = new UnionFind();
  for (let i = 1; i <= 10; i += 1) uf.add(`CN${i}`);
  components.flatMap(componentEndpoints).forEach(e => uf.add(e.id));
  resistors.forEach(r => {
    uf.add(r.a);
    uf.add(r.b);
  });
  wires.forEach(w => uf.union(w.a, w.b));

  const byKind = (kind: ComponentKind) =>
    components.filter(c => c.kind === kind);
  byKind('TC').forEach(c => {
    if (state.tcPressed) uf.union(`${c.id}.A`, `${c.id}.B`);
  });
  byKind('TG').forEach(c =>
    uf.union(`${c.id}.COM`, state.tgHigh ? `${c.id}.UP` : `${c.id}.DOWN`)
  );
  const encoderContacts = [0, 1, 3, 2][((state.encoderPhase % 4) + 4) % 4];
  byKind('ENC').forEach(c => {
    if (encoderContacts & 1) uf.union(`${c.id}.COM`, `${c.id}.A`);
    if (encoderContacts & 2) uf.union(`${c.id}.COM`, `${c.id}.B`);
  });

  const targetToCn: Partial<Record<ArduinoTarget, string[]>> = {};
  for (let pin = 1; pin <= 10; pin += 1) {
    const target = mapping[pin];
    if (!targetToCn[target]) targetToCn[target] = [];
    targetToCn[target]!.push(`CN${pin}`);
  }
  Object.values(targetToCn).forEach(cnList => {
    if (!cnList || cnList.length < 2) return;
    cnList.slice(1).forEach(cn => uf.union(cnList[0], cn));
  });

  const fixedGroups = new Map<string, Set<number>>();
  const addFixed = (endpoint: string, voltage: number) => {
    const root = uf.find(endpoint);
    if (!fixedGroups.has(root)) fixedGroups.set(root, new Set());
    fixedGroups.get(root)!.add(voltage);
  };
  (targetToCn['5V'] || []).forEach(cn => addFixed(cn, 5));
  (targetToCn.GND || []).forEach(cn => addFixed(cn, 0));

  const baseEdges: Edge[] = resistors.map(r => ({
    a: r.a,
    b: r.b,
    r: r.value,
  }));
  byKind('VR').forEach(c => baseEdges.push(...potEdges(`${c.id}.`, state.vr)));
  byKind('JOY').forEach(c => {
    const x = Math.max(0.001, Math.min(0.999, state.joyX));
    const y = Math.max(0.001, Math.min(0.999, state.joyY));
    baseEdges.push(
      { a: `${c.id}.XA`, b: `${c.id}.XW`, r: 10000 * x },
      { a: `${c.id}.XW`, b: `${c.id}.XB`, r: 10000 * (1 - x) }
    );
    baseEdges.push(
      { a: `${c.id}.YA`, b: `${c.id}.YW`, r: 10000 * y },
      { a: `${c.id}.YW`, b: `${c.id}.YB`, r: 10000 * (1 - y) }
    );
  });

  const solve = (edges: Edge[]) => {
    const roots = new Set<string>();
    for (let i = 1; i <= 10; i += 1) roots.add(uf.find(`CN${i}`));
    components
      .flatMap(componentEndpoints)
      .forEach(e => roots.add(uf.find(e.id)));
    edges.forEach(e => {
      roots.add(uf.find(e.a));
      roots.add(uf.find(e.b));
    });

    const adj = new Map<string, Array<{ other: string; g: number }>>();
    const link = (a: string, b: string, g: number) => {
      if (!adj.has(a)) adj.set(a, []);
      adj.get(a)!.push({ other: b, g });
    };
    edges.forEach(e => {
      const a = uf.find(e.a);
      const b = uf.find(e.b);
      if (a === b) return;
      const g = 1 / Math.max(0.001, e.r);
      link(a, b, g);
      link(b, a, g);
    });

    const reachable = new Set<string>();
    const queue: string[] = [];
    fixedGroups.forEach((_v, root) => {
      reachable.add(root);
      queue.push(root);
    });
    while (queue.length) {
      const current = queue.shift()!;
      (adj.get(current) || []).forEach(({ other }) => {
        if (!reachable.has(other)) {
          reachable.add(other);
          queue.push(other);
        }
      });
    }

    const voltages = new Map<string, number>();
    roots.forEach(r => voltages.set(r, 2.5));
    let shorted = false;
    fixedGroups.forEach((values, root) => {
      if (values.size > 1) {
        shorted = true;
        voltages.set(root, 2.5);
      } else voltages.set(root, [...values][0]);
    });

    for (let iteration = 0; iteration < 80; iteration += 1) {
      roots.forEach(root => {
        if (fixedGroups.has(root) || !reachable.has(root)) return;
        const neighbors = adj.get(root) || [];
        let numerator = 0;
        let denominator = 0;
        neighbors.forEach(({ other, g }) => {
          numerator += (voltages.get(other) ?? 2.5) * g;
          denominator += g;
        });
        if (denominator > 0) voltages.set(root, numerator / denominator);
      });
    }
    return { voltages, reachable, shorted };
  };

  const first = solve(baseEdges);
  const sensorEdges = [...baseEdges];
  const voltageAt = (endpoint: string) => first.voltages.get(uf.find(endpoint));
  const ledPowered = (c: Component) => {
    const va = voltageAt(`${c.id}.A`);
    const vk = voltageAt(`${c.id}.K`);
    return typeof va === 'number' && typeof vk === 'number' && va - vk > 1.1;
  };
  byKind('PH').forEach(c => {
    const on = ledPowered(c) && state.phTransparent;
    sensorEdges.push({ a: `${c.id}.C`, b: `${c.id}.E`, r: on ? 900 : 1e9 });
  });
  byKind('PR').forEach(c => {
    const level = ledPowered(c) ? Math.max(0, Math.min(1, state.prLevel)) : 0;
    const r = level <= 0.001 ? 1e9 : 1200 / level;
    sensorEdges.push({ a: `${c.id}.C`, b: `${c.id}.E`, r });
  });
  const final = solve(sensorEdges);

  const endpointVoltage: Record<string, number | null> = {};
  const allEndpoints = [
    ...Array.from({ length: 10 }, (_v, i) => `CN${i + 1}`),
    ...components.flatMap(componentEndpoints).map(e => e.id),
  ];
  allEndpoints.forEach(endpoint => {
    const root = uf.find(endpoint);
    endpointVoltage[endpoint] = final.reachable.has(root)
      ? (final.voltages.get(root) ?? null)
      : null;
  });

  const arduinoVoltage: Partial<Record<ArduinoTarget, number | null>> = {};
  const floatingTargets: ArduinoTarget[] = [];
  const targets: ArduinoTarget[] = [
    'D1',
    'D3',
    'D5',
    'D7',
    'D9',
    'D20',
    'D21',
    'A2',
    'A4',
    'A6',
    'A8',
  ];
  targets.forEach(target => {
    const cns = targetToCn[target] || [];
    if (!cns.length) return;
    const raw = endpointVoltage[cns[0]];
    if (raw === null) {
      const unstable =
        ((Math.sin(floatNoise * 91.73 + target.charCodeAt(1) * 1.37) + 1) / 2) *
        5;
      arduinoVoltage[target] = unstable;
      floatingTargets.push(target);
    } else arduinoVoltage[target] = raw;
  });

  return {
    endpointVoltage,
    arduinoVoltage,
    shorted: final.shorted,
    floatingTargets,
  };
}

export type FunctionalCheck = {
  id: string;
  label: string;
  pass: boolean;
  detail: string;
};

export function functionalCircuitChecks(
  components: Component[],
  wires: Wire[],
  resistors: Resistor[],
  mapping: Record<number, ArduinoTarget>,
  state: InputState
): FunctionalCheck[] {
  const checks: FunctionalCheck[] = [];
  const digitalTargets: ArduinoTarget[] = ['D1', 'D3', 'D5', 'D7', 'D9', 'D20', 'D21'];
  const analogTargets: ArduinoTarget[] = ['A2', 'A4', 'A6', 'A8'];
  const run = (patch: Partial<InputState>) =>
    solveCircuit(components, wires, resistors, mapping, { ...state, ...patch }, 0.347);
  const kinds = new Set(components.map(component => component.kind));
  const changedDigital = (a: SolveResult, b: SolveResult) =>
    digitalTargets.filter(target =>
      !a.floatingTargets.includes(target) &&
      !b.floatingTargets.includes(target) &&
      digitalLabel(a.arduinoVoltage[target]) !== digitalLabel(b.arduinoVoltage[target])
    );
  const changedAnalog = (a: SolveResult, b: SolveResult, minimum = 80) =>
    analogTargets.filter(target => {
      if (a.floatingTargets.includes(target) || b.floatingTargets.includes(target)) return false;
      const av = analogValue(a.arduinoVoltage[target]);
      const bv = analogValue(b.arduinoVoltage[target]);
      return av !== null && bv !== null && Math.abs(av - bv) >= minimum;
    });

  const safetyStates: Partial<InputState>[] = [
    {},
    { tcPressed: false },
    { tcPressed: true },
    { tgHigh: false },
    { tgHigh: true },
    { phTransparent: false },
    { phTransparent: true },
  ];
  if (kinds.has('ENC')) {
    [0, 1, 2, 3].forEach(encoderPhase => safetyStates.push({ encoderPhase }));
  }
  const hasShort = safetyStates.some(patch => run(patch).shorted);
  checks.push({
    id: 'short',
    label: '5V / GND 短絡',
    pass: !hasShort,
    detail: hasShort
      ? '入力を操作した状態を含めて、5V/GNDの直結が発生します。'
      : '入力状態を切り替えても5V/GND直結は検出されていません。',
  });

  if (kinds.has('TC')) {
    const pass = changedDigital(run({ tcPressed: false }), run({ tcPressed: true })).length > 0;
    checks.push({ id: 'TC', label: 'TC', pass, detail: pass ? '押下/解放で安定したデジタル変化があります。' : '押下/解放で安定したデジタル変化を確認できません。' });
  }
  if (kinds.has('TG')) {
    const pass = changedDigital(run({ tgHigh: false }), run({ tgHigh: true })).length > 0;
    checks.push({ id: 'TG', label: 'TG', pass, detail: pass ? '上下切替で安定したデジタル変化があります。' : '上下切替で安定したデジタル変化を確認できません。' });
  }
  if (kinds.has('PH')) {
    const pass = changedDigital(run({ phTransparent: false }), run({ phTransparent: true })).length > 0;
    checks.push({ id: 'PH', label: 'PH', pass, detail: pass ? '遮断/透過で安定したデジタル変化があります。' : '遮断/透過で安定したデジタル変化を確認できません。' });
  }
  if (kinds.has('PR')) {
    const pass = changedAnalog(run({ prLevel: 0.15 }), run({ prLevel: 0.9 })).length > 0;
    checks.push({ id: 'PR', label: 'PR', pass, detail: pass ? '反射量の変化がアナログ入力へ届いています。' : '反射量の変化が安定したアナログ入力へ届いていません。' });
  }
  if (kinds.has('VR')) {
    const pass = changedAnalog(run({ vr: 0.1 }), run({ vr: 0.9 }), 300).length > 0;
    checks.push({ id: 'VR', label: 'VR', pass, detail: pass ? 'ボリューム位置の変化がアナログ入力へ届いています。' : 'ボリューム位置の変化が安定したアナログ入力へ届いていません。' });
  }
  if (kinds.has('JOY')) {
    const xTargets = changedAnalog(run({ joyX: 0.1 }), run({ joyX: 0.9 }), 300);
    const yTargets = changedAnalog(run({ joyY: 0.1 }), run({ joyY: 0.9 }), 300);
    const pass = xTargets.length > 0 && yTargets.some(target => !xTargets.includes(target));
    checks.push({ id: 'JOY', label: 'JOY', pass, detail: pass ? 'X/Yの2軸が別々のアナログ入力として変化します。' : 'X/Yの2軸を独立した安定入力として確認できません。' });
  }
  if (kinds.has('ENC')) {
    const phases = [0, 1, 2, 3].map(encoderPhase => run({ encoderPhase }));
    const dynamicTargets = digitalTargets.filter(target => {
      if (phases.some(result => result.floatingTargets.includes(target))) return false;
      const labels = new Set(phases.map(result => digitalLabel(result.arduinoVoltage[target])));
      return labels.size > 1;
    });
    const pass = dynamicTargets.length >= 2;
    checks.push({ id: 'ENC', label: 'RE / ENC', pass, detail: pass ? 'A/Bの2相信号が独立して変化します。' : 'A/Bの2相信号を独立した安定入力として確認できません。' });
  }

  return checks;
}

export function digitalLabel(voltage: number | null | undefined) {
  if (voltage == null) return '?';
  if (voltage <= 1.5) return 'LOW';
  if (voltage >= 3.0) return 'HIGH';
  return '不定';
}

export function analogValue(voltage: number | null | undefined) {
  if (voltage == null) return null;
  return Math.max(0, Math.min(1023, Math.round((voltage / 5) * 1023)));
}

export function provisionalDcmRps(speed: number) {
  if (speed < 10) return 0;
  const x = (Math.min(250, speed) - 10) / 240;
  return 2.4 * Math.pow(Math.max(0, x), 0.9);
}

export function provisionalPhoDrop(speed: number) {
  if (speed < 150) return 0;
  return Math.min(0.12, 0.02 + ((speed - 150) / 100) * 0.1);
}
